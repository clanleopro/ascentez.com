import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { u as useQuoteModal } from "./router-reYbVChe.mjs";
const logoLight = "/assets/logo-light-Djg0x8wR.png";
const logoDark = "/assets/logo-dark-B8JWIN3g.png";
const links = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { to: "/services", label: "Services" },
  { to: "/fleet", label: "Fleet" },
  { to: "/case-studies", label: "Case Studies" },
  { to: "/contact", label: "Contact" }
];
function Nav({ dark = false }) {
  const { open } = useQuoteModal();
  const [menuOpen, setMenuOpen] = reactExports.useState(false);
  reactExports.useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e) => {
      if (e.key === "Escape") setMenuOpen(false);
    };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [menuOpen]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: `nav${dark ? " dark" : ""}`, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/", className: "nav-logo", "aria-label": "Ascentez home", onClick: () => setMenuOpen(false), children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "img",
        {
          src: dark ? logoLight : logoDark,
          alt: "Ascentez",
          className: "nav-logo-img"
        }
      ) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("nav", { className: "nav-links", children: links.map((l) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        Link,
        {
          to: l.to,
          activeProps: { className: "active" },
          activeOptions: { exact: l.to === "/" },
          children: l.label
        },
        l.to
      )) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "nav-cta", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => open("Header"),
            className: "btn btn-red nav-cta-btn",
            style: { padding: "10px 18px", fontSize: 11 },
            children: [
              "Contact Sales ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "arrow", children: "→" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            className: `nav-burger${menuOpen ? " open" : ""}`,
            "aria-label": menuOpen ? "Close menu" : "Open menu",
            "aria-expanded": menuOpen,
            onClick: () => setMenuOpen((v) => !v),
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", {}),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", {}),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", {})
            ]
          }
        )
      ] })
    ] }),
    menuOpen && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          className: "nav-scrim",
          "aria-label": "Close menu",
          onClick: () => setMenuOpen(false)
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("aside", { className: `nav-drawer${dark ? " dark" : ""}`, role: "dialog", "aria-modal": "true", "aria-label": "Site menu", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "nav-drawer-eyebrow", children: "Menu" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("nav", { className: "nav-drawer-links", children: links.map((l) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          Link,
          {
            to: l.to,
            activeProps: { className: "active" },
            activeOptions: { exact: l.to === "/" },
            onClick: () => setMenuOpen(false),
            children: l.label
          },
          l.to
        )) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => {
              setMenuOpen(false);
              open("Header · Mobile");
            },
            className: "btn btn-red nav-drawer-cta",
            children: [
              "Contact Sales ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "arrow", children: "→" })
            ]
          }
        )
      ] })
    ] })
  ] });
}
function Footer() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("footer", { className: "footer", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "footer-grid", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "f-brand", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: logoLight, alt: "Ascentez", className: "footer-logo-img" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Heavy lifting, transportation, and rigging for industrial projects across the Middle East. Engineered. Supervised. Delivered." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { children: "Sitemap" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/", children: "Home" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/about", children: "About" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/services", children: "Services" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/fleet", children: "Fleet" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/case-studies", children: "Case Studies" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/contact", children: "Contact" }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { children: "Capabilities" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/services", children: "Lift Engineering" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/services", children: "Heavy Transportation" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/services", children: "Rigging and Supervision" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/services", children: "Crane Rental" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/services", children: "Lifting Tools (Rental and Trading)" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/services", children: "Manpower and APLO" }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { children: "Headquarters" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "footer-hq", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Mohamed Bin Zayed City" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Abu Dhabi, U.A.E" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "tel:+971588776556", children: "+971 58 877 6556" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "mailto:info@ascentez.com", children: "info@ascentez.com" }) })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "footer-base", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
        "© ",
        (/* @__PURE__ */ new Date()).getFullYear(),
        " Ascentez Engineering Services L.L.C - S.P.C"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "We Rise By Lifting Others" })
    ] })
  ] }) });
}
export {
  Footer as F,
  Nav as N
};
