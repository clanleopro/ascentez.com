import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { N as Nav, F as Footer } from "./Footer-DBex5_Iw.mjs";
import { C as CraneBlueprint } from "./Cranes-CMmyy7bM.mjs";
import "./index.mjs";

import "../_libs/seroval.mjs";

import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "./router-reYbVChe.mjs";
import "../_libs/lovable.dev__email-js.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/unenv.mjs";


import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/zod.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




function AboutPage() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Nav, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "about-hero", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: {
        gridColumn: "1 / -1"
      }, children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eyebrow eyebrow-red", children: "About Ascentez · Engineering Services L.L.C - S.P.C" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "about-hero-h1", children: [
          "We lift",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "what others",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "won't." }),
          " And we",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "do it safely."
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "sub", children: "Ascentez is a heavy lifting and heavy transportation company based in Mohamed Bin Zayed City, Abu Dhabi. We work across the UAE on the lifts that need engineering, not just a crane." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "about-hero-visual", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CraneBlueprint, { className: "crane-svg" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "annot top", children: "BOOM · 108M" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "annot mid", children: "CC2800-1" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "annot low", children: "250T CW" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "about-crumbs", style: {
        gridColumn: "1 / -1"
      }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          "Founded",
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Abu Dhabi" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          "Crane Capacity",
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "45t to 1,600t" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          "Main Boom",
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Up to 108m" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          "Compliance",
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "ADNOC OS-ST-19" })
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "overview", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "wrap", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "overview-grid", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eyebrow eyebrow-red", children: "Overview" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "overview-h2", style: {
          marginTop: 20
        }, children: [
          "Built for the",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "difficult" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "lifts."
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "overview-body", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "lead", children: "We plan, engineer, and deliver heavy lifts and heavy transportation for industrial projects across the UAE. Our work covers oil and gas, cement, energy, mining, and infrastructure. Repeat clients and referrals make up most of what we do." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Our fleet runs from 45-tonne mobile cranes to 1,600-tonne crawlers, backed by SPMTs, boom trucks, trailers, and a full inventory of certified rigging gear. Every asset is inspected, certified, and ready to mobilise." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { children: [
          "Ascentez operates as a ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "single point of authority" }),
          ". Lift engineering, on-site supervision, rigging, and manpower sit under one accountable team. We produce 2D and 3D lift plans, review subcontractor submissions, and supervise execution on site. Every project runs to ADNOC HSE OS-ST-19."
        ] })
      ] })
    ] }) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "mv", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mv-card", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mv-label", children: "Mission" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "mv-h3", children: [
            "Deliver heavy",
            /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
            "lifts that are",
            /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
            "safe and on",
            /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
            "schedule."
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Deliver heavy lifting and heavy transportation that are engineered, documented, and on schedule. Nothing more, nothing less. No surprises for the client." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mv-num", children: "01" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mv-card", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mv-label", children: "Vision" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "mv-h3", children: [
            "Be the first",
            /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
            "call when",
            /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
            "the lift is",
            /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
            "critical."
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Be the name UAE industry thinks of first when the lift is at height, in a confined space, under a tight window, or under live plant conditions." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mv-num", children: "02" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "values", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "section-head", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eyebrow eyebrow-red", children: "Core Values" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "section-h2", children: [
          "The five",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "non-negotiables."
        ] }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "values-grid", children: [["01", "Safety First", "Every lift runs through ADNOC OS-ST-19. JSA, pre-lift inspection, competency verification, toolbox talk. Before the crane arrives, not after."], ["02", "Precision and Expertise", "A 43-tonne module in a confined footprint does not forgive rushing. We take the time to get the plan right, then execute fast."], ["03", "Engineered, Not Guessed", "2D and 3D simulation on every non-routine lift. Verified load charts. Documented sequences. No figuring it out on the day."], ["04", "Sustainability", "Route studies that cut unnecessary transport kilometres. Equipment choices that reduce fuel burn. Green practices where they do not compromise safety."], ["05", "Accountable to the Client", "Our Appointed Person stays on your site, not on a phone in Dubai. One named engineer owns every project from mobilisation to demob."]].map(([n, t, d]) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "value", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "v-icon", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { width: "44", height: "44", viewBox: "0 0 44 44", fill: "none", stroke: "currentColor", strokeWidth: "1.4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M22 4 L38 10 L38 22 C38 32 30 38 22 40 C14 38 6 32 6 22 L6 10 Z" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M15 22 L20 27 L30 17", strokeWidth: "1.6" })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "v-num", children: n }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { children: t }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: d })
      ] }, n)) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "process", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "section-head", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eyebrow eyebrow-red", children: "Process" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "section-h2", children: [
          "Five steps.",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "Every ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "project." })
        ] }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "proc-list", children: [["01", "Scope and Site Walk", "We read the drawings, walk the site, and flag the constraints. Ground conditions, clearances, live-plant risks.", ["Drawings", "Site Walk"]], ["02", "Engineer the Lift", "2D layout, 3D simulation, load chart verification, rigging calculations, sequencing plan.", ["2D/3D Plan", "Load Chart", "JSA"]], ["03", "Review and Approve", "Client HSE, consultant, and where applicable ADNOC review. We close every comment before mobilisation.", ["HSE", "ADNOC Review"]], ["04", "Mobilise and Execute", "Crane assembly, rigging inspection, JSA, toolbox talk. Lift under direct supervision by the APLO.", ["APLO", "Toolbox Talk"]], ["05", "Demobilise and Close Out", "As-done drawings. Lift log. Inspection records. Everything the client needs for their file.", ["Closeout", "Lift Log"]]].map(([n, p, b, tags]) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "proc-row", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "proc-num", children: n }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "proc-phase", children: p }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "proc-body", children: b }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "proc-tags", children: tags.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "proc-tag", children: t }, t)) })
      ] }, n)) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "hq", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hq-card", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "hq-label", children: "Headquarters" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { children: [
          "Abu Dhabi.",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "On the ground."
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("address", { children: [
          "Ascentez Engineering Services L.L.C - S.P.C",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "Office No. M3, Mezzanine Floor",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "Building No. C149, Sector M11",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "Mohamed Bin Zayed City",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "Abu Dhabi, United Arab Emirates"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hq-details", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "row", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Phone" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "v", children: "+971 2 639 2249" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "row", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Mobile / WhatsApp" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "v", children: "+971 58 877 6556" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "row", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Email" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "v", children: "info@ascentez.com" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/contact", className: "btn btn-red", style: {
          marginTop: 32
        }, children: [
          "Contact Us ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "arrow", children: "→" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hq-map", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pin" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pin-label", children: "ASCENTEZ HQ" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: {
          position: "absolute",
          top: 20,
          left: 20,
          fontFamily: "var(--f-mono)",
          fontSize: 10,
          letterSpacing: "0.2em",
          color: "var(--red)"
        }, children: `N 24°22'53" · E 54°33'34"` }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: {
          position: "absolute",
          bottom: 20,
          right: 20,
          fontFamily: "var(--f-mono)",
          fontSize: 10,
          letterSpacing: "0.2em",
          color: "var(--steel-2)"
        }, children: "MBZ CITY · SECTOR M11" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Footer, {})
  ] });
}
export {
  AboutPage as component
};
