import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { N as Nav, F as Footer } from "./Footer-DBex5_Iw.mjs";
import "./index.mjs";

import "../_libs/seroval.mjs";

import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "./router-reYbVChe.mjs";
import "../_libs/lovable.dev__email-js.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/unenv.mjs";


import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/zod.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




const cases = [{
  id: "borouge",
  num: "01 · Borouge 3 · Flare Tip Replacement",
  owner: "Owner · Borouge",
  title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    "Five flare tips. 190 ",
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "metres" }),
    " up.",
    /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
    "Two metres of clearance."
  ] }),
  scope: "Borouge 3 needed five 5-tonne flare tips swapped at the top of a 190-metre flare tower during a live-plant shutdown window. Clearance between the crane boom and the flare tower was 2 metres. Wind conditions on the stack were high. The lift could not slip the schedule.",
  specs: [["Crane", "Demag CC8800-1 (1,600T)"], ["Configuration", "SWSL"], ["Main Boom", "108m at 88°"], ["Jib", "108m"], ["Working Radius", "68m"], ["Chart Used", "84.18%"]],
  detail: [["Approach", "We built a 3D simulation of the lift before mobilisation. We reviewed and validated the subcontractor's lift plans. We supervised assembly and dismantling of the Demag CC8800-1, then supervised the flare tip operation itself."], ["Outcome", "Five flare tips replaced. Man baskets and material baskets landed. Zero incidents. ADNOC HSE OS-ST-19 compliance documented end to end."]]
}, {
  id: "lafarge",
  num: "02 · Lafarge Cement Plant · AQC and SP Boiler",
  owner: "Owner · Lafarge Emirates Cement · Client · ENGIE · Consultant · Bureau Veritas",
  title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    "One crawler. Five lifts.",
    /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
    "One ",
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "confined" }),
    " footprint."
  ] }),
  scope: "AQC and SP Boiler installation inside an operating cement plant. 43-tonne modules and 36-tonne flue gas ducts needed placement in a confined area with strict safety control. The contractor's lift plans also needed review and approval before execution.",
  specs: [["Crane", "Demag CC2800-1"], ["Boom", "SSL/LSL · 96m"], ["Max Lift", "43t module"], ["Chart Used", "90.2% peak"], ["Assist", "Sany STC750"], ["Lifts", "5 documented"]],
  detail: [["Approach", "We prepared the primary lift plans for the AQC Boiler and SP Boiler work. We reviewed and approved subcontractor lift plans. We supervised every lift on site. One Demag CC2800-1 in SSL/LSL configuration handled the heavy lifts. A Sany STC750 assisted on the hopper duct tailing operation."], ["Lift log", "SP Boiler Module 43t at 54m, 190t SL, 85.91% chart. Flue Gas Duct 36.23t at 62m, 250t SL, 90.2% chart. Boiler Tube Bundle 30t at 54m, 170t SL, 84.26%. Hopper Ducts 21.12t at 54m, 85.12% (with Sany STC750 assist at 35.53%). Support Duct 3.05t at 66m, 0t SL, 84.83%."], ["Outcome", "All lifts landed. No rework. No reschedule. Primary and subcontractor lift plans approved and filed."]]
}, {
  id: "gasco",
  num: "03 · Gasco Habshan · Plant Shutdown Support",
  owner: "Owner · ADNOC Gas (Gasco)",
  title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    "Confined-space lifts,",
    /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "in a live" }),
    " shutdown window."
  ] }),
  scope: "Valve and spool replacements inside an operating gas plant. Hard-to-access locations. A shutdown window that could not slip. Full ADNOC HSE OS-ST-19 compliance required for every lift.",
  specs: [["Cranes", "Mobile 50t to 80t"], ["Scope", "Valve and Spool"], ["Role", "APLO Supervision"], ["Standard", "ADNOC OS-ST-19"], ["Environment", "Hard-access"], ["Outcome", "Zero incidents"]],
  detail: [["Approach", "Mobile cranes from 50 to 80 tonnes mobilised to each work area. Every lift classified, risk-assessed, and signed off before execution."], ["Compliance", "Detailed lifting plans prepared and approved. Competency validation for lifting personnel, riggers, and signallers. Pre-lift inspections of cranes, lifting gear, and ground conditions. Classification of lifting operations (critical vs non-critical) with risk assessments. Toolbox Talks and JSA before every lift. Continuous supervision and emergency preparedness."], ["Outcome", "Shutdown scope completed. Zero incidents. Full ADNOC HSE OS-ST-19 compliance documented."]]
}, {
  id: "takreer",
  num: "04 · Takreer Ruwais · Heat Exchanger Tube Bundles",
  owner: "Owner · ADNOC Refining (Takreer)",
  title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    "Sinking soil, 110t mobile,",
    /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "zero rework." })
  ] }),
  scope: "Heavy tube bundle replacement during a Ruwais refinery shutdown. Ground conditions were unstable. Soil was sinking under load. Crane positioning and load spreading had to be worked out before anything moved.",
  specs: [["Cranes", "95t and 110t mobile"], ["Scope", "Tube Bundles, Catalyst"], ["Challenge", "Sinking soil"], ["Standard", "ADNOC OS-ST-19"], ["Role", "Planning and APLO"], ["Outcome", "Safe, on plan"]],
  detail: [["Approach", "Mobile cranes of 95 and 110 tonnes mobilised with full load-spreading mats. Bearing pressure calculations signed off for every setup. Lift plans prepared and reviewed. Supervision continuous on site."], ["Compliance", "Lift plan preparation, review, and approval. Operator, rigger, and signaller competency verification. Pre-lift inspection of cranes, tackles, and ground stability. Lift classification and risk assessment. Toolbox Talks and JSA before execution. Continuous supervision and emergency preparedness."], ["Outcome", "Heat exchanger tube bundles replaced. Catalyst replaced. Ground stability maintained throughout. Full ADNOC HSE OS-ST-19 compliance logged."]]
}];
function CaseStudiesPage() {
  const [expanded, setExpanded] = reactExports.useState(null);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Nav, { dark: true }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "cs-hero", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eyebrow eyebrow-red", children: "Case Studies" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "cs-hero-h1", style: {
          marginTop: 28
        }, children: [
          "Four projects.",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "Four ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "reasons" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "to call us."
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "summary", children: "Each project below was chosen because something about it was harder than a textbook lift. Height. Clearance. Soil. Access. A live plant overhead. What follows is what we did and what we used." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "legend", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "04 Projects" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "08 Critical Lifts" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "1600T Fleet" })
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "cs-vertical", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "wrap", children: cases.map((c, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("article", { id: c.id, className: `cs-card${expanded === c.id ? " expanded" : ""}`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hero-art", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "placeholder-label", children: "PROJECT PHOTO · PLACEHOLDER" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "serial", children: [
          "CASE · 0",
          i + 1,
          " / 04"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "num", children: c.num }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "owner", children: c.owner }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "cs-card-h3", children: c.title })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "scope", children: c.scope }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "specs", children: c.specs.map(([k, v]) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "k", children: k }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "v", children: v })
      ] }, k)) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "cs-expand-btn", onClick: () => setExpanded(expanded === c.id ? null : c.id), children: expanded === c.id ? "Collapse Detail ←" : "Expand Detail →" }),
      expanded === c.id && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "cs-detail", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: c.detail.map(([h, p]) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { children: h }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: p })
        ] }, h)) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "cs-annotated" })
      ] })
    ] }, c.id)) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "cs-cta", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eyebrow eyebrow-red", children: "Got a project like these?" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "cs-cta-h2", style: {
          marginTop: 20
        }, children: [
          "Start a",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "conversation." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { style: {
          color: "var(--steel)",
          fontSize: 17,
          lineHeight: 1.6,
          marginTop: 24,
          maxWidth: 520
        }, children: "We respond to every serious inquiry within one working day. Send the load, the site, and the window." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/contact", className: "download", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "meta", children: "PDF · Rev 3 · 15 Pages" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { children: [
          "Ascentez",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "Project Portfolio"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "inline-link", children: "Start a Conversation →" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Footer, {})
  ] });
}
export {
  CaseStudiesPage as component
};
