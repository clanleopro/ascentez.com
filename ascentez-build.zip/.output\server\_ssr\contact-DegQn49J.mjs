import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { N as Nav, F as Footer } from "./Footer-DBex5_Iw.mjs";
import { P as PhoneInput } from "./router-reYbVChe.mjs";
import "./index.mjs";

import "../_libs/seroval.mjs";

import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/lovable.dev__email-js.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/unenv.mjs";


import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/zod.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




const inquiryTypes = ["Lift Engineering", "Crane Rental", "Transportation", "Tools Rental", "Tools Trading", "Manpower", "General"];
const serviceLines = [{
  n: "01",
  name: "Lift Engineering",
  desc: "Lift studies, 3D plans, rigging design.",
  contact: "info@ascentez.com"
}, {
  n: "02",
  name: "Crane Rental",
  desc: "Crawler, mobile, all-terrain. Operated or bare.",
  contact: "info@ascentez.com"
}, {
  n: "03",
  name: "Transportation",
  desc: "SPMTs, low-beds, route surveys.",
  contact: "info@ascentez.com"
}, {
  n: "04",
  name: "Tools Rental & Trading",
  desc: "Spreader beams, frames, slings, shackles.",
  contact: "info@ascentez.com"
}, {
  n: "05",
  name: "Manpower",
  desc: "APLO, riggers, supervisors, safety officers.",
  contact: "info@ascentez.com"
}, {
  n: "06",
  name: "General Inquiries",
  desc: "Partnerships, vendor onboarding, media.",
  contact: "info@ascentez.com"
}];
function ContactPage() {
  const [type, setType] = reactExports.useState("Lift Engineering");
  const [sent, setSent] = reactExports.useState(false);
  const submit = (e) => {
    e.preventDefault();
    setSent(true);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Nav, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "ct-hero", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "wrap", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-hero-grid", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eyebrow eyebrow-red", children: "Contact · Abu Dhabi · U.A.E" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "ct-hero-h1", children: [
          "Let's talk",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "about ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "heavy" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "italic-serif", style: {
            color: "var(--steel)"
          }, children: "things." })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-hero-aside", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "ct-hero-lede", children: "Send us the load and the location. A named engineer replies within one working day." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-quick", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { href: "tel:+971588776556", className: "ct-quick-row", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "k", children: "Call" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "v", children: "+971 58 877 6556" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { href: "https://wa.me/971588776556", target: "_blank", rel: "noopener noreferrer", className: "ct-quick-row", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "k", children: "WhatsApp" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "v", children: "+971 58 877 6556" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { href: "mailto:info@ascentez.com", className: "ct-quick-row", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "k", children: "Email" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "v", children: "info@ascentez.com" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { href: "tel:+97126392249", className: "ct-quick-row", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "k", children: "Office" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "v", children: "+971 2 639 2249" })
          ] })
        ] })
      ] })
    ] }) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "ct-strip", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap ct-strip-grid", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eyebrow eyebrow-red", children: "Headquarters" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "ct-addr", children: [
          "Ascentez Engineering Services L.L.C - S.P.C",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "Office No. M3, Mezzanine Floor",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "Building No. C149, Sector M11",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "Mohamed Bin Zayed City",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "Abu Dhabi, United Arab Emirates"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eyebrow eyebrow-red", children: "Hours" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "ct-addr", children: [
          "Sun to Thu · 08:00 to 18:00 GST",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "Site response · 24 / 7 for shutdowns",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "Reply window · within one working day"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eyebrow eyebrow-red", children: "Follow" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "ct-addr", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "https://linkedin.com/company/ascentez", target: "_blank", rel: "noopener noreferrer", children: "LinkedIn" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "https://youtube.com/@Ascentez", target: "_blank", rel: "noopener noreferrer", children: "YouTube" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "https://wa.me/971588776556", target: "_blank", rel: "noopener noreferrer", children: "WhatsApp Channel" })
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "ct-form-section", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-form-head", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eyebrow eyebrow-red", children: "General Inquiry" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "ct-form-h2-big", children: [
            "Send us",
            /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
            "a ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "message." })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "ct-form-lede", children: "The more specific you are about scope, location, weight, and schedule, the faster we can respond with a real answer instead of a holding email." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "ct-form-card", children: !sent ? /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: submit, className: "ct-form", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "row", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-field", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { children: "Full name" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "text", name: "name", required: true, placeholder: "Your name" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-field", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { children: "Company" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "text", name: "company", placeholder: "Company or organisation" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "row", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-field", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { children: "Email" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "email", name: "email", required: true, placeholder: "you@company.com" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-field", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { children: "Phone" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(PhoneInput, { name: "phone" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-field", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { children: "Inquiry type" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "ct-chip-row", children: inquiryTypes.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", className: `ct-chip${type === t ? " selected" : ""}`, onClick: () => setType(t), children: t }, t)) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "row", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-field", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { children: "Project location" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "text", name: "location", placeholder: "e.g. Ruwais, Habshan, Taweelah" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-field", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { children: "Expected load weight" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "text", name: "load", placeholder: "e.g. 40T module, 120T transformer" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-field", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { children: "Target schedule" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "text", name: "schedule", placeholder: "When do you need it?" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-field", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { children: "Message" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("textarea", { name: "message", rows: 4, placeholder: "Tell us what you need." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-form-foot", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-form-note", children: [
            "Or skip the form. ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "mailto:info@ascentez.com", style: {
              color: "var(--red)",
              borderBottom: "1px solid var(--red)"
            }, children: "info@ascentez.com" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "submit", className: "btn btn-red", children: [
            "Send Inquiry ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "arrow", children: "→" })
          ] })
        ] })
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-success show", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "check", children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { width: "32", height: "32", viewBox: "0 0 24 24", fill: "none", stroke: "var(--red)", strokeWidth: "2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("polyline", { points: "4 12 10 18 20 6" }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { children: [
          "Message ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "sent." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "muted", children: "Thanks. We have your message. A named engineer will reply within one working day. If this is urgent, WhatsApp us on +971 58 877 6556." })
      ] }) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "ct-lines", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-lines-head", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eyebrow eyebrow-red", children: "Direct Lines" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "fleet-h2", children: [
            "By service",
            /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "line." })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Skip the switchboard. Write to the discipline that owns the work." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-lines-table", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ctl-row head", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "#" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Service" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "What it covers" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Direct email" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", {})
        ] }),
        serviceLines.map((s) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ctl-row", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "tn", children: s.n }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "tname", children: s.name }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "tdesc", children: s.desc }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "tmail", children: /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: `mailto:${s.contact}`, children: s.contact }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/contact", className: "tcta", children: "Write →" })
        ] }, s.n))
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "final-cta-f", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eyebrow", style: {
        color: "#0A0A0A"
      }, children: "Operations · Abu Dhabi" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "final-cta-h2", children: [
        "Heavy work.",
        /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
        "Specific answers."
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Tell us the load, the site, and the date. We respond with people, not auto-replies." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { href: "https://wa.me/971588776556", target: "_blank", rel: "noopener noreferrer", className: "btn", children: [
        "WhatsApp Us ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "arrow", children: "→" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Footer, {})
  ] });
}
export {
  ContactPage as component
};
