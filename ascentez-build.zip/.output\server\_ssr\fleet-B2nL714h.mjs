import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { N as Nav, F as Footer } from "./Footer-DBex5_Iw.mjs";
import { I as IconCrawler, a as IconMobile, b as IconSPMT } from "./Cranes-CMmyy7bM.mjs";
import { u as useQuoteModal } from "./router-reYbVChe.mjs";
import "./index.mjs";

import "../_libs/seroval.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/lovable.dev__email-js.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/unenv.mjs";


import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/zod.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




function nodeToText(n) {
  if (n == null || typeof n === "boolean") return "";
  if (typeof n === "string" || typeof n === "number") return String(n);
  if (Array.isArray(n)) return n.map(nodeToText).join(" ");
  if (typeof n === "object" && "props" in n) {
    const el = n;
    if (el.type === "br") return " ";
    return nodeToText(el.props?.children);
  }
  return "";
}
const crawlers = [{
  tag: "Crawler · Flagship",
  model: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    "Demag",
    /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
    "CC8800-1"
  ] }),
  cap: "1,600",
  unit: "T",
  specs: [["Main Boom", "Up to 108m"], ["Jib", "108m"], ["Best Use", "Flare tip and heavy module"]]
}, {
  tag: "Crawler · Workhorse",
  model: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    "Demag",
    /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
    "CC2800-1"
  ] }),
  cap: "600",
  unit: "T",
  specs: [["Main Boom", "96m SSL/LSL"], ["SL Counterweight", "Up to 250t"], ["Best Use", "Cement plant and structural"]]
}, {
  tag: "Crawler · Mid",
  model: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    "Mid-range",
    /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
    "Crawler"
  ] }),
  cap: "250",
  unit: "T",
  specs: [["Capacity", "80t to 250t"], ["Boom", "Up to 70m"], ["Best Use", "Infrastructure, bridge, wind"]]
}];
const mobiles = [{
  tag: "All-Terrain · 500t Class",
  model: "AT · 500t",
  cap: "500",
  unit: "T",
  specs: [["Main Boom", "60m"], ["Best Use", "Heavy shutdown"], ["Availability", "Operated"]]
}, {
  tag: "All-Terrain · 200t Class",
  model: "AT · 200t",
  cap: "200",
  unit: "T",
  specs: [["Boom", "64m telescopic"], ["Best Use", "Refinery and industrial"], ["Availability", "Operated or bare"]]
}, {
  tag: "All-Terrain · 80t Class",
  model: "AT · 80t",
  cap: "80",
  unit: "T",
  specs: [["Boom", "48m telescopic"], ["Best Use", "Valve, spool, access"], ["Availability", "Operated or bare"]]
}];
const transports = [{
  tag: "SPMT",
  model: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    "Self-Propelled",
    /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
    "Modular Transporter"
  ] }),
  cap: "500",
  unit: "T+",
  specs: [["Configuration", "Modular and scalable"], ["Best Use", "Heavy module and refinery"]]
}, {
  tag: "Low-Bed Trailer",
  model: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    "Low-Bed",
    /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
    "Trailer"
  ] }),
  cap: "120",
  unit: "T",
  specs: [["Axles", "Up to 8-axle"], ["Best Use", "Site-to-site moves"]]
}, {
  tag: "Boom Truck and Forklift",
  model: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    "Support",
    /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
    "Equipment"
  ] }),
  cap: "20",
  unit: "T",
  specs: [["Fleet", "Boom truck, forklift"], ["Best Use", "Yard and light handling"]]
}];
const tools = [["01", "Spreader Beam", "Standard and modular spreader beams, load-tested and certified.", "5t to 1,000t"], ["02", "Lifting Frame", "Square and cross lifting frames. Jumbo bag frames for 2 to 20 bags simultaneously.", "1t to 100t"], ["03", "Bow Shackles", "Marine-grade bow and dee shackles, Green Pin and equivalent.", "Up to 1,250t"], ["04", "Chain Pulley Block", "Manual and lever-operated chain blocks. Kito, Yale, Vital in stock.", "Up to 40t"], ["05", "Webbing and Wire Rope Slings", "Polyester round slings, webbing slings, wire rope slings with reinforced terminations.", "EN and ASME"], ["06", "Modular Test Weight", "Calibrated test weights for proof-load testing of cranes and hoists.", "1t to 100t"], ["07", "Man and Material Basket", "Engineered personnel and material baskets with certified lifting points.", "All sizes"], ["08", "Turnbuckles", "Heavy-duty turnbuckles for load stabilisation.", "Various"]];
function EqCard({
  icon,
  tag,
  model,
  cap,
  unit,
  specs,
  onRequest
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "eq-card", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eq-icon", children: icon }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eq-tag", children: tag }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eq-model", children: model }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "eq-cap", children: [
      cap,
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "unit", children: unit })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eq-specs", children: specs.map(([k, v]) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "eq-spec-row", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: k }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "v", children: v })
    ] }, k)) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", className: "eq-cta", onClick: onRequest, children: [
      "Request Quote ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "arrow", children: "→" })
    ] })
  ] });
}
function FleetPage() {
  const {
    open
  } = useQuoteModal();
  const reqCrawler = (c) => open({
    source: `Fleet · ${nodeToText(c.model).trim()} (${c.cap}${c.unit})`,
    presetType: "Crane Rental · Crawler"
  });
  const reqMobile = (c) => open({
    source: `Fleet · ${nodeToText(c.model).trim()} (${c.cap}${c.unit})`,
    presetType: "Crane Rental · Mobile"
  });
  const reqTransport = (c) => open({
    source: `Fleet · ${nodeToText(c.model).trim()} (${c.cap}${c.unit})`,
    presetType: "Heavy Transportation"
  });
  const reqTool = (name, range) => open({
    source: `Fleet · ${name} (${range})`,
    presetType: "Tools Rental"
  });
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Nav, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "fleet-hero", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eyebrow eyebrow-red", children: "Equipment Fleet" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "fleet-hero-h1", style: {
          marginTop: 28
        }, children: [
          "From 45",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "t" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "to 1,600",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "t." }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "italic-serif", style: {
            color: "var(--steel-2)"
          }, children: "one fleet." })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { style: {
          color: "var(--steel-2)",
          fontSize: 17,
          lineHeight: 1.6
        }, children: "Mobile cranes, crawler cranes, SPMTs, boom trucks, and a full inventory of certified rigging gear. Every asset inspected, certified, and ready to mobilise." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "counts", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            "Mobile",
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "45t to 500t" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            "Crawler",
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "80t to 1,600t" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            "Transport",
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "SPMT and low-bed" })
          ] })
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("nav", { className: "fleet-tabs", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("a", { className: "fleet-tab active", href: "#crawler", children: "Crawler Cranes" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("a", { className: "fleet-tab", href: "#mobile", children: "Mobile Cranes" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("a", { className: "fleet-tab", href: "#transport", children: "Transportation" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("a", { className: "fleet-tab", href: "#tools", children: "Lifting Tools" })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "fleet-section", id: "crawler", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fleet-head", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eyebrow eyebrow-red", children: "01 · Crawlers" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "fleet-h2", children: [
            "Crawler",
            /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "Cranes" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Heavy lattice-boom crawler cranes for the biggest lifts. Boiler modules, flare tips, wind components. Delivered, assembled, operated, and demobilised." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eq-grid", children: crawlers.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx(EqCard, { ...c, icon: /* @__PURE__ */ jsxRuntimeExports.jsx(IconCrawler, {}), onRequest: () => reqCrawler(c) }, c.tag)) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "fleet-section alt", id: "mobile", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fleet-head", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eyebrow eyebrow-red", children: "02 · Mobile" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "fleet-h2", children: [
            "Mobile",
            /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
            "Cranes"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "All-terrain and rough-terrain mobile cranes for fast mobilisation and restricted-access sites." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eq-grid", children: mobiles.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx(EqCard, { ...c, icon: /* @__PURE__ */ jsxRuntimeExports.jsx(IconMobile, {}), onRequest: () => reqMobile(c) }, c.tag)) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "fleet-section", id: "transport", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fleet-head", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eyebrow eyebrow-red", children: "03 · Transport" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "fleet-h2", children: [
            "Heavy",
            /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "Transportation" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "SPMTs, low-bed trailers, boom trucks, and support equipment for oversized and overweight cargo." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eq-grid", children: transports.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx(EqCard, { ...c, icon: /* @__PURE__ */ jsxRuntimeExports.jsx(IconSPMT, {}), onRequest: () => reqTransport(c) }, c.tag)) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "fleet-section alt", id: "tools", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "fleet-head", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eyebrow eyebrow-red", children: "04 · Tools" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "fleet-h2", children: [
            "Lifting Tools",
            /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
            "Rental and Trading"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Certified spreader beams, frames, baskets, shackles, and slings. Inspected, tagged, ready." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "tool-table", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "tool-row head", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "#" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Item" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Description" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Range" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", {})
        ] }),
        tools.map(([n, name, desc, range]) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "tool-row", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "tn", children: n }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "tname", children: name }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "tdesc", children: desc }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "trange", children: range }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", className: "tcta", onClick: () => reqTool(name, range), children: "Request →" })
        ] }, n))
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { style: {
        marginTop: 32,
        fontFamily: "var(--f-mono)",
        fontSize: 12,
        letterSpacing: "0.14em",
        color: "var(--steel)",
        textTransform: "uppercase"
      }, children: "Fleet partners and manufacturers we run: Demag · Liebherr · Grove · Sany · Kito · Yale · Green Pin" })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "final-cta-f", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eyebrow", style: {
        color: "#0A0A0A"
      }, children: "Ready to mobilise" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "final-cta-h2", children: [
        "Pick the crane.",
        /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
        "We will do the rest."
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Share your scope and we will configure the right asset. Delivered, operated, insured, certified." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", className: "btn", onClick: () => open({
        source: "Fleet · Final CTA",
        presetType: "Crane Rental"
      }), children: [
        "Request a Crane ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "arrow", children: "→" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Footer, {})
  ] });
}
export {
  FleetPage as component
};
