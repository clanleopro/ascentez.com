import { p as performance } from "../_libs/unenv.mjs";
import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { N as Nav, F as Footer } from "./Footer-DBex5_Iw.mjs";
import { C as CraneBlueprint, I as IconCrawler, b as IconSPMT, c as IconHook } from "./Cranes-CMmyy7bM.mjs";
import { u as useQuoteModal } from "./router-reYbVChe.mjs";
import "./index.mjs";

import "../_libs/seroval.mjs";



import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/lovable.dev__email-js.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/zod.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




const items = [
  { l: "Fleet", v: "45t — 1,600t" },
  { l: "Boom", v: "108m main + 108m jib" },
  { l: "Compliance", v: "ADNOC OS-ST-19" },
  { l: "HQ", v: "Abu Dhabi · UAE" },
  { l: "Response", v: "<24h" },
  { l: "Safety", v: "Zero LTI" }
];
function Ticker() {
  const row = /* @__PURE__ */ jsxRuntimeExports.jsx(jsxRuntimeExports.Fragment, { children: items.map((it, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
    it.l,
    " ",
    /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: it.v }),
    " ·"
  ] }, i)) });
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "ticker", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ticker-track", children: [
    row,
    row
  ] }) });
}
const CLIENTS = [{
  name: "ADNOC",
  logo: "https://logo.clearbit.com/adnoc.ae"
}, {
  name: "Borouge",
  logo: "https://logo.clearbit.com/borouge.com"
}, {
  name: "Lafarge",
  logo: "https://logo.clearbit.com/lafarge.com"
}, {
  name: "ENGIE",
  logo: "https://logo.clearbit.com/engie.com"
}, {
  name: "Bureau Veritas",
  logo: "https://logo.clearbit.com/bureauveritas.com"
}, {
  name: "ADNOC Gas",
  logo: "https://logo.clearbit.com/adnocgas.ae"
}, {
  name: "ADNOC Refining",
  logo: "https://logo.clearbit.com/adnoc.ae"
}, {
  name: "Emirates Steel",
  logo: "https://logo.clearbit.com/emiratessteel.com"
}];
function HomePage() {
  const {
    open
  } = useQuoteModal();
  reactExports.useEffect(() => {
    const els = document.querySelectorAll(".reveal");
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          e.target.classList.add("is-visible");
          io.unobserve(e.target);
        }
      });
    }, {
      threshold: 0.15
    });
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Nav, { dark: true }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Ticker, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "hero-v1", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hero-v1-numbers", children: [
        `N 24°26'00"`,
        /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
        `E 54°26'00"`,
        /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
        "ABU DHABI · UAE",
        /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
        "LAT · 45°",
        /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
        "BOOM · 108M",
        /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
        "CAP · 1600T"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "wrap", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hero-v1-grid", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hero-v1-left", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "hero-v1-eyebrow", children: "Heavy Lifting and Transportation · Est. Abu Dhabi" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "hero-v1-h1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hero-lift-mask", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hero-lift-inner", children: "We Rise" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hero-lift-mask", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "hero-lift-inner d1", children: [
              "by ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "Lifting" })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hero-lift-mask", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "hero-lift-inner d2 stroke", children: "Others." }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "hero-v1-sub", children: "We plan, engineer, and execute the heaviest lifts in the UAE. Oil and gas, cement, energy, infrastructure. From 45-tonne mobile cranes to 1,600-tonne crawlers, under one accountable team." }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hero-v1-actions", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: () => open("Hero · Request Lift Plan"), className: "btn btn-red", children: [
              "Request a Lift Plan ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "arrow", children: "→" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/case-studies", className: "btn btn-ghost-dark", children: [
              "View Our Work ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "arrow", children: "→" })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hero-v1-meta", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { style: {
                color: "var(--steel-2)"
              }, children: "Crane Fleet" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "45t to 1,600t" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { style: {
                color: "var(--steel-2)"
              }, children: "Compliance" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "ADNOC HSE OS-ST-19" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { style: {
                color: "var(--steel-2)"
              }, children: "Reach" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "108m main boom" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hero-v1-right", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CraneBlueprint, { className: "crane-svg" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "spec-tag t1", children: "BOOM · 108M · ANGLE · 88°" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "spec-tag t2", children: "WORKING RADIUS · 68M" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "spec-tag t3", children: "CHART CAP · 84.18%" })
        ] })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "stats reveal", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "wrap", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "stats-grid", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Stat, { target: 12e3, formatter: (n) => n.toLocaleString(), unit: "T+", label: "Tonnes Lifted" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Stat, { target: 140, unit: "+", label: "Projects Delivered" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Stat, { target: 1600, formatter: (n) => n.toLocaleString(), unit: "T", label: "Max Crane Capacity" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Stat, { target: 190, unit: "M", label: "Highest Lift: Borouge 3" })
    ] }) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "industries reveal", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "section-head", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eyebrow eyebrow-red", children: "Industries" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "section-h2", children: [
            "Built for the heaviest",
            /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
            "work on earth."
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "section-p", children: "We work where precision and safety cannot slip. Six sectors. One playbook. Every lift planned on paper and in 3D before anything moves on site." })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "ind-list", children: [["01", "Oil and Gas", "Refineries, flare systems, pipeline support. Full ADNOC HSE OS-ST-19 compliance."], ["02", "Construction and Infrastructure", "Bridges, high-rise buildings, modular construction."], ["03", "Cement", "AQC boilers, SP boilers, flue ducts, tube bundles. Lifts inside live plants."], ["04", "Energy and Power", "Wind turbine erection, transformers, power plant modules."], ["05", "Mining", "Haulage of mining machinery, processing equipment, on-site installation."], ["06", "Manufacturing", "Industrial machinery transport. Route surveys included."]].map(([n, name, desc]) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/services", className: "ind-row", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "ind-num", children: [
          n,
          " /"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "ind-name", children: name }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "ind-desc", children: desc }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "ind-cta", children: "Explore →" })
      ] }, n)) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "svc-teaser reveal", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "section-head", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eyebrow eyebrow-red", children: "What We Do" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "section-h2", children: [
            "Three disciplines.",
            /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
            "One ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "accountable" }),
            " team."
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "section-p", children: "A single point of authority for the entire lifting lifecycle. Engineered plans, certified equipment, qualified manpower, on-site supervision. One team, one standard." })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "svc-cards", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ServiceCard, { to: "/services", hash: "lift-engineering", tag: "01 / Engineering", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(IconCrawler, {}), title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          "Lift",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "Engineering"
        ] }), desc: "2D and 3D lift plans, route studies, load chart verification, rigging design. The documentation that gets your HSE team to sign off." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(ServiceCard, { to: "/services", hash: "transportation", tag: "02 / Transport", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(IconSPMT, {}), title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          "Heavy",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "Transportation"
        ] }), desc: "SPMTs, trailers, boom trucks. Oversized load studies, route surveys, end-to-end logistics for heavy cargo." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(ServiceCard, { to: "/services", hash: "rigging", tag: "03 / Execution", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(IconHook, {}), title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          "Rigging",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "and Supervision"
        ] }), desc: "APLO, rigging supervisors, safety officers on site. Rigging, jacking, and turnkey execution of complex lifts." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: {
        textAlign: "center",
        marginTop: 60
      }, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/services", className: "btn", children: [
        "All Services ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "arrow", children: "→" })
      ] }) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "editorial-block reveal", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "kicker", children: "Our Discipline" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("blockquote", { children: [
          "Precision runs the job.",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "Everything else ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "serves that." })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "notes", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Every lift is a controlled event. We draw it first on paper and in 3D. We verify the load chart at the working radius. We confirm the rigger's certification. We inspect the shackle before the shift." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: 'When a 5-tonne flare tip swings 190 metres off the deck with 2 metres of clearance to the flare tower, "almost" is not an acceptable answer. We do the boring paperwork so the lift itself is never dramatic.' }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/about", className: "inline-link", style: {
          marginTop: 24
        }, children: "How we work →" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "cs-teaser reveal", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "section-head", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eyebrow eyebrow-red", children: "Selected Projects" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "section-h2", children: [
            "Lifts of ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "record." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "section-p", children: "Four flagship projects for ADNOC, Borouge, Lafarge, and Takreer. Each one a lift the other bidders said could not be done on that schedule, on that crane, in that footprint. Each one delivered." })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "cs-list", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/case-studies", className: "cs-feature", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "placeholder" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "cs-owner", children: "Borouge 3 · Flare Tip Replacement" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { children: [
              "Five flare tips,",
              /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
              "190 metres up."
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "cs-meta-grid", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "k", children: "Crane" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "v", children: "Demag CC8800-1" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "k", children: "Boom" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "v", children: "108m plus 108m jib" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "k", children: "Chart Used" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "v", children: "84.18%" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "cs-side", children: [["Lafarge", "Cement Plant", "AQC and SP Boiler · 43T Module"], ["Gasco", "Habshan", "Shutdown · Valve and Spool"], ["Takreer", "Ruwais", "Heat Exchanger Tube Bundles"]].map(([t1, t2, m]) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/case-studies", className: "cs-mini", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { children: [
              t1,
              /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
              t2
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "cs-mini-meta", children: m })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: "→" })
        ] }, t1)) })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "clients reveal", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "wrap", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "clients-head", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eyebrow eyebrow-red", style: {
          justifyContent: "center"
        }, children: "Trusted By" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { children: "Major Operators and EPCs" })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "logo-marquee", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "logo-marquee-track", children: [...CLIENTS, ...CLIENTS].map((c, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "logo-cell", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: c.logo, alt: c.name, loading: "lazy", onError: (e) => {
          e.currentTarget.style.visibility = "hidden";
        } }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: c.name })
      ] }, `${c.name}-${i}`)) }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "final-cta reveal", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { children: [
        "Have something",
        /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
        "heavy to move?"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "lead", children: "Send us the load, the site, and the constraint. We reply within one working day with a first-pass plan or a clear next question." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hero-v1-actions", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: () => open("Final CTA"), className: "btn", children: [
          "Contact Sales ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "arrow", children: "→" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/contact", className: "btn btn-ghost-dark", children: "Contact Page" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Footer, {})
  ] });
}
function Stat({
  target,
  unit,
  label,
  formatter
}) {
  const ref = reactExports.useRef(null);
  const [val, setVal] = reactExports.useState(0);
  const started = reactExports.useRef(false);
  reactExports.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting && !started.current) {
          started.current = true;
          const duration = 1800;
          const start = performance.now();
          const tick = (now) => {
            const t = Math.min(1, (now - start) / duration);
            const eased = 1 - Math.pow(1 - t, 3);
            setVal(Math.round(target * eased));
            if (t < 1) requestAnimationFrame(tick);
          };
          requestAnimationFrame(tick);
          io.disconnect();
        }
      });
    }, {
      threshold: 0.4
    });
    io.observe(el);
    return () => io.disconnect();
  }, [target]);
  const display = formatter ? formatter(val) : String(val);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "stat", ref, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "stat-value", children: [
      display,
      unit && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "unit", children: unit })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "stat-label", children: label })
  ] });
}
function ServiceCard({
  tag,
  icon,
  title,
  desc,
  to,
  hash
}) {
  const content = /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "svc-tag", children: tag }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "svc-icon", children: icon }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { children: title }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "svc-desc", children: desc }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "svc-arrow", children: "Learn More →" })
  ] });
  if (to) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to, hash, className: "svc-card", children: content });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "svc-card", children: content });
}
export {
  HomePage as component
};
