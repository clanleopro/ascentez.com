import { T as TSS_SERVER_FUNCTION, c as createServerFn } from "./index.mjs";

import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import { o as objectType, s as stringType } from "../_libs/zod.mjs";

import "../_libs/h3-v2.mjs";
import "../_libs/unenv.mjs";


import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";





import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";

import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
var createServerRpc = (serverFnMeta, splitImportFn) => {
  const url = "/_serverFn/" + serverFnMeta.id;
  return Object.assign(splitImportFn, {
    url,
    serverFnMeta,
    [TSS_SERVER_FUNCTION]: true
  });
};
objectType({
  name: stringType().trim().min(1).max(120),
  company: stringType().trim().max(160).optional().default(""),
  email: stringType().trim().email().max(255),
  phone: stringType().trim().max(40).optional().default(""),
  type: stringType().trim().max(80),
  location: stringType().trim().max(200).optional().default(""),
  load: stringType().trim().max(200).optional().default(""),
  schedule: stringType().trim().max(200).optional().default(""),
  message: stringType().trim().max(2e3).optional().default("")
});
async function submitInquiryOnServer(data) {
  console.log("[Ascentez Inquiry]", JSON.stringify(data));
  return { ok: true, receivedAt: (/* @__PURE__ */ new Date()).toISOString() };
}
const InquirySchema = objectType({
  name: stringType().trim().min(1).max(120),
  company: stringType().trim().max(160).optional().default(""),
  email: stringType().trim().email().max(255),
  phone: stringType().trim().max(40).optional().default(""),
  type: stringType().trim().max(80),
  location: stringType().trim().max(200).optional().default(""),
  load: stringType().trim().max(200).optional().default(""),
  schedule: stringType().trim().max(200).optional().default(""),
  message: stringType().trim().max(2e3).optional().default("")
});
const submitInquiry_createServerFn_handler = createServerRpc({
  id: "3aa892ca26e0ad02dbc16191048721137d8c36abb145f47071a39a45af32d9f4",
  name: "submitInquiry",
  filename: "src/functions/inquiries.functions.ts"
}, (opts) => submitInquiry.__executeServer(opts));
const submitInquiry = createServerFn({
  method: "POST"
}).inputValidator((input) => InquirySchema.parse(input)).handler(submitInquiry_createServerFn_handler, async ({
  data
}) => submitInquiryOnServer(data));
export {
  submitInquiry_createServerFn_handler
};
