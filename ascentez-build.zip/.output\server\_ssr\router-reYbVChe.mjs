import process from "node:process";
import { j as jsxRuntimeExports, r as reactExports } from "../_libs/react.mjs";
import { c as createRouter, u as useRouter, a as createRootRoute, b as createFileRoute, l as lazyRouteComponent, H as HeadContent, S as Scripts, O as Outlet, L as Link } from "../_libs/tanstack__react-router.mjs";
import { l as isRedirect } from "../_libs/tanstack__router-core.mjs";
import { c as createServerFn, T as TSS_SERVER_FUNCTION, g as getServerFnById } from "./index.mjs";
import { s as sendLovableEmail } from "../_libs/lovable.dev__email-js.mjs";
import { c as createClient } from "../_libs/supabase__supabase-js.mjs";
import { o as objectType, s as stringType } from "../_libs/zod.mjs";
import "../_libs/react-dom.mjs";

import "../_libs/isbot.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/unenv.mjs";


import "../_libs/seroval-plugins.mjs";


import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
function useServerFn(serverFn) {
  const router2 = useRouter();
  return reactExports.useCallback(async (...args) => {
    try {
      const res = await serverFn(...args);
      if (isRedirect(res)) throw res;
      return res;
    } catch (err) {
      if (isRedirect(err)) {
        err.options._fromLocation = router2.stores.location.get();
        return router2.navigate(router2.resolveRedirect(err).options);
      }
      throw err;
    }
  }, [router2, serverFn]);
}
const appCss = "/assets/styles-CC8XCjyM.css";
var createSsrRpc = (functionId) => {
  const url = "/_serverFn/" + functionId;
  const serverFnMeta = { id: functionId };
  const fn = async (...args) => {
    return (await getServerFnById(functionId))(...args);
  };
  return Object.assign(fn, {
    url,
    serverFnMeta,
    [TSS_SERVER_FUNCTION]: true
  });
};
const InquirySchema = objectType({
  name: stringType().trim().min(1).max(120),
  company: stringType().trim().max(160).optional().default(""),
  email: stringType().trim().email().max(255),
  phone: stringType().trim().max(40).optional().default(""),
  type: stringType().trim().max(80),
  location: stringType().trim().max(200).optional().default(""),
  load: stringType().trim().max(200).optional().default(""),
  schedule: stringType().trim().max(200).optional().default(""),
  message: stringType().trim().max(2e3).optional().default("")
});
const submitInquiry = createServerFn({
  method: "POST"
}).inputValidator((input) => InquirySchema.parse(input)).handler(createSsrRpc("3aa892ca26e0ad02dbc16191048721137d8c36abb145f47071a39a45af32d9f4"));
const COUNTRIES = [
  { code: "AE", dial: "+971", name: "United Arab Emirates" },
  { code: "SA", dial: "+966", name: "Saudi Arabia" },
  { code: "QA", dial: "+974", name: "Qatar" },
  { code: "OM", dial: "+968", name: "Oman" },
  { code: "BH", dial: "+973", name: "Bahrain" },
  { code: "KW", dial: "+965", name: "Kuwait" },
  { code: "IN", dial: "+91", name: "India" },
  { code: "PK", dial: "+92", name: "Pakistan" },
  { code: "BD", dial: "+880", name: "Bangladesh" },
  { code: "PH", dial: "+63", name: "Philippines" },
  { code: "EG", dial: "+20", name: "Egypt" },
  { code: "JO", dial: "+962", name: "Jordan" },
  { code: "LB", dial: "+961", name: "Lebanon" },
  { code: "TR", dial: "+90", name: "Turkey" },
  { code: "GB", dial: "+44", name: "United Kingdom" },
  { code: "US", dial: "+1", name: "United States" },
  { code: "CA", dial: "+1", name: "Canada" },
  { code: "DE", dial: "+49", name: "Germany" },
  { code: "FR", dial: "+33", name: "France" },
  { code: "IT", dial: "+39", name: "Italy" },
  { code: "ES", dial: "+34", name: "Spain" },
  { code: "NL", dial: "+31", name: "Netherlands" },
  { code: "CH", dial: "+41", name: "Switzerland" },
  { code: "SE", dial: "+46", name: "Sweden" },
  { code: "NO", dial: "+47", name: "Norway" },
  { code: "AU", dial: "+61", name: "Australia" },
  { code: "NZ", dial: "+64", name: "New Zealand" },
  { code: "JP", dial: "+81", name: "Japan" },
  { code: "KR", dial: "+82", name: "South Korea" },
  { code: "CN", dial: "+86", name: "China" },
  { code: "SG", dial: "+65", name: "Singapore" },
  { code: "MY", dial: "+60", name: "Malaysia" },
  { code: "ID", dial: "+62", name: "Indonesia" },
  { code: "TH", dial: "+66", name: "Thailand" },
  { code: "ZA", dial: "+27", name: "South Africa" },
  { code: "NG", dial: "+234", name: "Nigeria" },
  { code: "KE", dial: "+254", name: "Kenya" },
  { code: "BR", dial: "+55", name: "Brazil" },
  { code: "MX", dial: "+52", name: "Mexico" },
  { code: "RU", dial: "+7", name: "Russia" }
];
function PhoneInput({ name = "phone", defaultDial = "+971", required, maxLength = 40, placeholder = "58 877 6556" }) {
  const [dial, setDial] = reactExports.useState(defaultDial);
  const [number, setNumber] = reactExports.useState("");
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "phone-input-wrap", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "select",
      {
        className: "phone-dial",
        value: dial,
        onChange: (e) => setDial(e.target.value),
        "aria-label": "Country code",
        children: COUNTRIES.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: c.dial, children: [
          c.dial,
          "  (",
          c.name,
          ")"
        ] }, c.code))
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "input",
      {
        type: "tel",
        className: "phone-number",
        value: number,
        onChange: (e) => setNumber(e.target.value),
        required,
        maxLength,
        placeholder,
        "aria-label": "Phone number"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "hidden", name, value: number ? `${dial} ${number}` : "" })
  ] });
}
const QuoteCtx = reactExports.createContext(null);
function useQuoteModal() {
  const ctx = reactExports.useContext(QuoteCtx);
  if (!ctx) throw new Error("QuoteModal context missing");
  return ctx;
}
const inquiryTypes = [
  "Lift Engineering",
  "Crane Rental",
  "Heavy Transportation",
  "Rigging & Supervision",
  "Tools Rental",
  "Tools Trading",
  "Manpower / APLO"
];
function QuoteModalProvider({ children }) {
  const [isOpen, setIsOpen] = reactExports.useState(false);
  const [source, setSource] = reactExports.useState();
  const [presetType, setPresetType] = reactExports.useState();
  const open = reactExports.useCallback((opts) => {
    if (typeof opts === "string") {
      setSource(opts);
      setPresetType(void 0);
    } else {
      setSource(opts?.source);
      setPresetType(opts?.presetType);
    }
    setIsOpen(true);
  }, []);
  const close = reactExports.useCallback(() => setIsOpen(false), []);
  reactExports.useEffect(() => {
    if (!isOpen) return;
    const onKey = (e) => {
      if (e.key === "Escape") close();
    };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [isOpen, close]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(QuoteCtx.Provider, { value: { open, close }, children: [
    children,
    isOpen && /* @__PURE__ */ jsxRuntimeExports.jsx(QuoteDialog, { source, presetType, onClose: close })
  ] });
}
function QuoteDialog({ source, presetType, onClose }) {
  const submit = useServerFn(submitInquiry);
  const [type, setType] = reactExports.useState(presetType || "Lift Engineering");
  const chipOptions = presetType && !inquiryTypes.includes(presetType) ? [presetType, ...inquiryTypes] : inquiryTypes;
  const [status, setStatus] = reactExports.useState("idle");
  const [errorMsg, setErrorMsg] = reactExports.useState("");
  const onSubmit = async (e) => {
    e.preventDefault();
    if (status === "sending") return;
    const fd = new FormData(e.currentTarget);
    setStatus("sending");
    setErrorMsg("");
    try {
      await submit({
        data: {
          name: String(fd.get("name") || ""),
          company: String(fd.get("company") || ""),
          email: String(fd.get("email") || ""),
          phone: String(fd.get("phone") || ""),
          type,
          location: String(fd.get("location") || ""),
          load: String(fd.get("load") || ""),
          schedule: String(fd.get("schedule") || ""),
          message: String(fd.get("message") || "")
        }
      });
      setStatus("sent");
    } catch (err) {
      setStatus("error");
      setErrorMsg(err instanceof Error ? err.message : "Could not send. Try again.");
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "qm-overlay", role: "dialog", "aria-modal": "true", "aria-label": "Contact Sales", onClick: onClose, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "qm-panel", onClick: (e) => e.stopPropagation(), children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "qm-close", onClick: onClose, "aria-label": "Close", children: "×" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "qm-side", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "qm-eyebrow", children: "Contact Sales · Abu Dhabi" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "qm-title", children: [
        "Tell us",
        /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
        "what you need",
        /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "to lift." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "qm-sub", children: "We reply within one working day with a first-pass plan or a clear next question." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "qm-meta", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Phone" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "tel:+971588776556", children: "+971 58 877 6556" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Email" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "mailto:info@ascentez.com", children: "info@ascentez.com" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "HQ" }),
          "Mohamed Bin Zayed City, Abu Dhabi"
        ] }),
        source && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "From" }),
          source
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "qm-form-wrap", children: status === "sent" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "qm-success", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "qm-check", children: "✓" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { children: "Inquiry received." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Our team will reply within one working day." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "btn btn-red", onClick: onClose, children: "Close" })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit, className: "ct-form qm-form", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "row", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-field", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { children: "Full name" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "text", name: "name", required: true, maxLength: 120, placeholder: "Your name" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-field", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { children: "Company" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "text", name: "company", maxLength: 160, placeholder: "Company or organisation" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "row", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-field", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { children: "Email" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "email", name: "email", required: true, maxLength: 255, placeholder: "you@company.com" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-field", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { children: "Phone" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(PhoneInput, { name: "phone" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-field", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { children: "Inquiry type" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "ct-chip-row", children: chipOptions.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", className: `ct-chip${type === t ? " selected" : ""}`, onClick: () => setType(t), children: t }, t)) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "row", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-field", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { children: "Project location" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "text", name: "location", maxLength: 200, placeholder: "e.g. Ruwais, Habshan, Taweelah" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-field", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { children: "Expected load weight" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "text", name: "load", maxLength: 200, placeholder: "e.g. 40T module, 120T transformer" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-field", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { children: "Target schedule" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "text", name: "schedule", maxLength: 200, placeholder: "When do you need it?" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-field", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { children: "Message" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("textarea", { name: "message", rows: 4, maxLength: 2e3, placeholder: "Tell us what you need. The more specific, the faster we reply." })
      ] }),
      status === "error" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "qm-error", children: errorMsg }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-form-foot", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ct-form-note", children: [
          "Or email ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "mailto:info@ascentez.com", style: { color: "var(--red)", borderBottom: "1px solid var(--red)" }, children: "info@ascentez.com" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "submit", disabled: status === "sending", className: "btn btn-red", children: status === "sending" ? "Sending…" : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          "Send Inquiry ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "arrow", children: "→" })
        ] }) })
      ] })
    ] }) })
  ] }) });
}
function NotFoundComponent() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-7xl font-bold text-foreground", children: "404" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-4 text-xl font-semibold text-foreground", children: "Page not found" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "The page you're looking for doesn't exist or has been moved." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      Link,
      {
        to: "/",
        className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
        children: "Go home"
      }
    ) })
  ] }) });
}
const Route$7 = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Lovable App" },
      { name: "description", content: "Heavy lifting and transportation company" },
      { name: "author", content: "Lovable" },
      { property: "og:title", content: "Lovable App" },
      { property: "og:description", content: "Heavy lifting and transportation company" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "twitter:site", content: "@Lovable" },
      { name: "twitter:title", content: "Lovable App" },
      { name: "twitter:description", content: "Heavy lifting and transportation company" },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/6e8c0296-c5cb-4125-ba46-c581c9dd4f46/id-preview-fee3dc56--0f7826c8-14fc-4ff6-b1c6-c87f76cde3d2.lovable.app-1776838006136.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/6e8c0296-c5cb-4125-ba46-c581c9dd4f46/id-preview-fee3dc56--0f7826c8-14fc-4ff6-b1c6-c87f76cde3d2.lovable.app-1776838006136.png" }
    ],
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Archivo+Narrow:wght@400;500;600;700&family=Archivo:wght@400;500;600;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&family=Instrument+Serif&display=swap" },
      { rel: "stylesheet", href: appCss },
      { rel: "icon", type: "image/png", href: "/favicon.png" },
      { rel: "apple-touch-icon", href: "/favicon.png" }
    ]
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent
});
function RootShell({ children }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("html", { lang: "en", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("head", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(HeadContent, {}) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("body", { children: [
      children,
      /* @__PURE__ */ jsxRuntimeExports.jsx(Scripts, {})
    ] })
  ] });
}
function RootComponent() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(QuoteModalProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Outlet, {}) });
}
const $$splitComponentImporter$5 = () => import("./services-iX6E9oTt.mjs");
const Route$6 = createFileRoute("/services")({
  head: () => ({
    meta: [{
      title: "Services · Heavy Lift, Transport, Rigging · Ascentez"
    }, {
      name: "description",
      content: "Seven service lines under one team. Lift engineering, heavy transportation, rigging supervision, crane rental, lifting tools rental and trading, APLO manpower."
    }, {
      property: "og:title",
      content: "Ascentez Services · Heavy Lift and Transport"
    }, {
      property: "og:description",
      content: "From 2D and 3D lift plans to 1,600-tonne crane rental. One accountable team."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
const $$splitComponentImporter$4 = () => import("./fleet-B2nL714h.mjs");
const Route$5 = createFileRoute("/fleet")({
  head: () => ({
    meta: [{
      title: "Fleet · Cranes, SPMTs, Lifting Tools · Ascentez"
    }, {
      name: "description",
      content: "Crawler cranes 80t to 1,600t, mobile cranes 45t to 500t, SPMTs, low-beds, and certified rigging gear. Abu Dhabi based."
    }, {
      property: "og:title",
      content: "Ascentez Fleet · 45t to 1,600t"
    }, {
      property: "og:description",
      content: "Mobile cranes, crawler cranes, SPMTs, boom trucks, and a full inventory of certified rigging gear."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
const $$splitComponentImporter$3 = () => import("./contact-DegQn49J.mjs");
const Route$4 = createFileRoute("/contact")({
  head: () => ({
    meta: [{
      title: "Contact Ascentez · Abu Dhabi"
    }, {
      name: "description",
      content: "Talk to Ascentez about heavy lifts, transportation, and rigging. We respond within one working day. Mohamed Bin Zayed City, Abu Dhabi."
    }, {
      property: "og:title",
      content: "Contact Ascentez · Abu Dhabi"
    }, {
      property: "og:description",
      content: "Heavy things to move? Send us the load and the location. We reply within one working day."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
const $$splitComponentImporter$2 = () => import("./case-studies-DXjALoML.mjs");
const Route$3 = createFileRoute("/case-studies")({
  head: () => ({
    meta: [{
      title: "Case Studies · Borouge, Lafarge, Gasco, Takreer · Ascentez"
    }, {
      name: "description",
      content: "Four flagship heavy-lift projects in the UAE. Borouge 3 flare tip at 190m. Lafarge cement plant modules. Gasco Habshan. Takreer Ruwais refinery."
    }, {
      property: "og:title",
      content: "Ascentez Case Studies · Heavy Lifts Delivered"
    }, {
      property: "og:description",
      content: "190m flare tip. 43T cement modules. Refinery tube bundles. Lifts delivered under ADNOC OS-ST-19."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
const $$splitComponentImporter$1 = () => import("./about-O94QwzXw.mjs");
const Route$2 = createFileRoute("/about")({
  head: () => ({
    meta: [{
      title: "About Ascentez · Heavy Lift Engineering, Abu Dhabi"
    }, {
      name: "description",
      content: "Abu Dhabi based heavy lifting and transportation company. Mission, values, process, and HQ details. 45t to 1,600t crane fleet. ADNOC OS-ST-19."
    }, {
      property: "og:title",
      content: "About Ascentez · Heavy Lift Engineering"
    }, {
      property: "og:description",
      content: "We plan, engineer, and supervise the heaviest lifts in the UAE. One accountable team under the CEO."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
const $$splitComponentImporter = () => import("./index-DpyInype.mjs");
const Route$1 = createFileRoute("/")({
  head: () => ({
    meta: [{
      title: "Ascentez · Heavy Lifting and Transportation, Abu Dhabi"
    }, {
      name: "description",
      content: "Heavy lifts, heavy transportation, and rigging for industrial projects across the UAE. 45t to 1,600t crane fleet. ADNOC OS-ST-19 compliant. Abu Dhabi based."
    }, {
      property: "og:title",
      content: "Ascentez · Heavy Lifting and Transportation"
    }, {
      property: "og:description",
      content: "45-tonne mobile cranes to 1,600-tonne crawlers. Borouge 3 flare tip at 190m. Lafarge, Gasco, Takreer delivered."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter, "component")
});
const MAX_RETRIES = 5;
const DEFAULT_BATCH_SIZE = 10;
const DEFAULT_SEND_DELAY_MS = 200;
const DEFAULT_AUTH_TTL_MINUTES = 15;
const DEFAULT_TRANSACTIONAL_TTL_MINUTES = 60;
function isRateLimited(error) {
  if (error && typeof error === "object" && "status" in error) {
    return error.status === 429;
  }
  return error instanceof Error && error.message.includes("429");
}
function isForbidden(error) {
  if (error && typeof error === "object" && "status" in error) {
    return error.status === 403;
  }
  return error instanceof Error && error.message.includes("403");
}
function getRetryAfterSeconds(error) {
  if (error && typeof error === "object" && "retryAfterSeconds" in error) {
    return error.retryAfterSeconds ?? 60;
  }
  return 60;
}
async function moveToDlq(supabase, queue, msg, reason) {
  const payload = msg.message;
  await supabase.from("email_send_log").insert({
    message_id: payload.message_id,
    template_name: payload.label || queue,
    recipient_email: payload.to,
    status: "dlq",
    error_message: reason
  });
  const { error } = await supabase.rpc("move_to_dlq", {
    source_queue: queue,
    dlq_name: `${queue}_dlq`,
    message_id: msg.msg_id,
    payload
  });
  if (error) {
    console.error("Failed to move message to DLQ", { queue, msg_id: msg.msg_id, reason, error });
  }
}
const Route = createFileRoute("/lovable/email/queue/process")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const apiKey = process.env.LOVABLE_API_KEY;
        const supabaseUrl = "https://xholorppttnjtunzpvrm.supabase.co";
        const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
        if (!apiKey || !supabaseUrl || !supabaseServiceKey) {
          console.error("Missing required environment variables");
          return Response.json(
            { error: "Server configuration error" },
            { status: 500 }
          );
        }
        const authHeader = request.headers.get("Authorization");
        if (!authHeader?.startsWith("Bearer ")) {
          return Response.json({ error: "Unauthorized" }, { status: 401 });
        }
        const token = authHeader.slice("Bearer ".length).trim();
        if (token !== supabaseServiceKey) {
          return Response.json({ error: "Forbidden" }, { status: 403 });
        }
        const supabase = createClient(supabaseUrl, supabaseServiceKey);
        const { data: state } = await supabase.from("email_send_state").select("retry_after_until, batch_size, send_delay_ms, auth_email_ttl_minutes, transactional_email_ttl_minutes").single();
        if (state?.retry_after_until && new Date(state.retry_after_until) > /* @__PURE__ */ new Date()) {
          return Response.json({ skipped: true, reason: "rate_limited" });
        }
        const batchSize = state?.batch_size ?? DEFAULT_BATCH_SIZE;
        const sendDelayMs = state?.send_delay_ms ?? DEFAULT_SEND_DELAY_MS;
        const ttlMinutes = {
          auth_emails: state?.auth_email_ttl_minutes ?? DEFAULT_AUTH_TTL_MINUTES,
          transactional_emails: state?.transactional_email_ttl_minutes ?? DEFAULT_TRANSACTIONAL_TTL_MINUTES
        };
        let totalProcessed = 0;
        for (const queue of ["auth_emails", "transactional_emails"]) {
          const { data: messages, error: readError } = await supabase.rpc("read_email_batch", {
            queue_name: queue,
            batch_size: batchSize,
            vt: 30
          });
          if (readError) {
            console.error("Failed to read email batch", { queue, error: readError });
            continue;
          }
          if (!messages?.length) continue;
          const messageIds = Array.from(
            new Set(
              messages.map(
                (msg) => msg?.message?.message_id && typeof msg.message.message_id === "string" ? msg.message.message_id : null
              ).filter((id) => Boolean(id))
            )
          );
          const failedAttemptsByMessageId = /* @__PURE__ */ new Map();
          if (messageIds.length > 0) {
            const { data: failedRows, error: failedRowsError } = await supabase.from("email_send_log").select("message_id").in("message_id", messageIds).eq("status", "failed");
            if (failedRowsError) {
              console.error("Failed to load failed-attempt counters", {
                queue,
                error: failedRowsError
              });
            } else {
              for (const row of failedRows ?? []) {
                const messageId = row?.message_id;
                if (typeof messageId !== "string" || !messageId) continue;
                failedAttemptsByMessageId.set(
                  messageId,
                  (failedAttemptsByMessageId.get(messageId) ?? 0) + 1
                );
              }
            }
          }
          for (let i = 0; i < messages.length; i++) {
            const msg = messages[i];
            const payload = msg.message;
            const failedAttempts = payload?.message_id && typeof payload.message_id === "string" ? failedAttemptsByMessageId.get(payload.message_id) ?? 0 : msg.read_ct ?? 0;
            const queuedAt = payload.queued_at ?? msg.enqueued_at;
            if (queuedAt) {
              const ageMs = Date.now() - new Date(queuedAt).getTime();
              const maxAgeMs = ttlMinutes[queue] * 60 * 1e3;
              if (ageMs > maxAgeMs) {
                console.warn("Email expired (TTL exceeded)", {
                  queue,
                  msg_id: msg.msg_id,
                  queued_at: queuedAt,
                  ttl_minutes: ttlMinutes[queue]
                });
                await moveToDlq(supabase, queue, msg, `TTL exceeded (${ttlMinutes[queue]} minutes)`);
                continue;
              }
            }
            if (failedAttempts >= MAX_RETRIES) {
              await moveToDlq(supabase, queue, msg, `Max retries (${MAX_RETRIES}) exceeded (attempted ${failedAttempts} times)`);
              continue;
            }
            if (payload.message_id) {
              const { data: alreadySent } = await supabase.from("email_send_log").select("id").eq("message_id", payload.message_id).eq("status", "sent").maybeSingle();
              if (alreadySent) {
                console.warn("Skipping duplicate send (already sent)", {
                  queue,
                  msg_id: msg.msg_id,
                  message_id: payload.message_id
                });
                const { error: dupDelError } = await supabase.rpc("delete_email", {
                  queue_name: queue,
                  message_id: msg.msg_id
                });
                if (dupDelError) {
                  console.error("Failed to delete duplicate message from queue", { queue, msg_id: msg.msg_id, error: dupDelError });
                }
                continue;
              }
            }
            try {
              await sendLovableEmail(
                {
                  run_id: payload.run_id,
                  to: payload.to,
                  from: payload.from,
                  sender_domain: payload.sender_domain,
                  subject: payload.subject,
                  html: payload.html,
                  text: payload.text,
                  purpose: payload.purpose,
                  label: payload.label,
                  idempotency_key: payload.idempotency_key,
                  unsubscribe_token: payload.unsubscribe_token,
                  message_id: payload.message_id
                },
                { apiKey, sendUrl: process.env.LOVABLE_SEND_URL }
              );
              await supabase.from("email_send_log").insert({
                message_id: payload.message_id,
                template_name: payload.label || queue,
                recipient_email: payload.to,
                status: "sent"
              });
              const { error: delError } = await supabase.rpc("delete_email", {
                queue_name: queue,
                message_id: msg.msg_id
              });
              if (delError) {
                console.error("Failed to delete sent message from queue", { queue, msg_id: msg.msg_id, error: delError });
              }
              totalProcessed++;
            } catch (error) {
              const errorMsg = error instanceof Error ? error.message : String(error);
              console.error("Email send failed", {
                queue,
                msg_id: msg.msg_id,
                read_ct: msg.read_ct,
                failed_attempts: failedAttempts,
                error: errorMsg
              });
              if (isRateLimited(error)) {
                await supabase.from("email_send_log").insert({
                  message_id: payload.message_id,
                  template_name: payload.label || queue,
                  recipient_email: payload.to,
                  status: "failed",
                  error_message: errorMsg.slice(0, 1e3)
                });
                const retryAfterSecs = getRetryAfterSeconds(error);
                await supabase.from("email_send_state").update({
                  retry_after_until: new Date(
                    Date.now() + retryAfterSecs * 1e3
                  ).toISOString(),
                  updated_at: (/* @__PURE__ */ new Date()).toISOString()
                }).eq("id", 1);
                return Response.json({ processed: totalProcessed, stopped: "rate_limited" });
              }
              if (isForbidden(error)) {
                await moveToDlq(supabase, queue, msg, "Emails disabled for this project");
                return Response.json({ processed: totalProcessed, stopped: "emails_disabled" });
              }
              await supabase.from("email_send_log").insert({
                message_id: payload.message_id,
                template_name: payload.label || queue,
                recipient_email: payload.to,
                status: "failed",
                error_message: errorMsg.slice(0, 1e3)
              });
              if (payload?.message_id && typeof payload.message_id === "string") {
                failedAttemptsByMessageId.set(payload.message_id, failedAttempts + 1);
              }
            }
            if (i < messages.length - 1) {
              await new Promise((r) => setTimeout(r, sendDelayMs));
            }
          }
        }
        return Response.json({ processed: totalProcessed });
      }
    }
  }
});
const ServicesRoute = Route$6.update({
  id: "/services",
  path: "/services",
  getParentRoute: () => Route$7
});
const FleetRoute = Route$5.update({
  id: "/fleet",
  path: "/fleet",
  getParentRoute: () => Route$7
});
const ContactRoute = Route$4.update({
  id: "/contact",
  path: "/contact",
  getParentRoute: () => Route$7
});
const CaseStudiesRoute = Route$3.update({
  id: "/case-studies",
  path: "/case-studies",
  getParentRoute: () => Route$7
});
const AboutRoute = Route$2.update({
  id: "/about",
  path: "/about",
  getParentRoute: () => Route$7
});
const IndexRoute = Route$1.update({
  id: "/",
  path: "/",
  getParentRoute: () => Route$7
});
const LovableEmailQueueProcessRoute = Route.update({
  id: "/lovable/email/queue/process",
  path: "/lovable/email/queue/process",
  getParentRoute: () => Route$7
});
const rootRouteChildren = {
  IndexRoute,
  AboutRoute,
  CaseStudiesRoute,
  ContactRoute,
  FleetRoute,
  ServicesRoute,
  LovableEmailQueueProcessRoute
};
const routeTree = Route$7._addFileChildren(rootRouteChildren)._addFileTypes();
function DefaultErrorComponent({ error, reset }) {
  const router2 = useRouter();
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-destructive/10", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      "svg",
      {
        xmlns: "http://www.w3.org/2000/svg",
        className: "h-8 w-8 text-destructive",
        fill: "none",
        viewBox: "0 0 24 24",
        stroke: "currentColor",
        strokeWidth: 2,
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "path",
          {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            d: "M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z"
          }
        )
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-bold tracking-tight text-foreground", children: "Something went wrong" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "An unexpected error occurred. Please try again." }),
    false,
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 flex items-center justify-center gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => {
            router2.invalidate();
            reset();
          },
          className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
          children: "Try again"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "a",
        {
          href: "/",
          className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
          children: "Go home"
        }
      )
    ] })
  ] }) });
}
const getRouter = () => {
  const router2 = createRouter({
    routeTree,
    context: {},
    scrollRestoration: true,
    defaultPreloadStaleTime: 0,
    defaultErrorComponent: DefaultErrorComponent
  });
  return router2;
};
const router = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  getRouter
}, Symbol.toStringTag, { value: "Module" }));
export {
  PhoneInput as P,
  router as r,
  useQuoteModal as u
};
