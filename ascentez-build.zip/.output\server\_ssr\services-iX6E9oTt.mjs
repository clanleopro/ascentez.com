import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { N as Nav, F as Footer } from "./Footer-DBex5_Iw.mjs";
import { u as useQuoteModal } from "./router-reYbVChe.mjs";
import "./index.mjs";

import "../_libs/seroval.mjs";

import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";


import "../_libs/react-dom.mjs";
import "../_libs/isbot.mjs";
import "../_libs/lovable.dev__email-js.mjs";
import "../_libs/supabase__supabase-js.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/unenv.mjs";


import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "../_libs/tslib.mjs";
import "../_libs/supabase__functions-js.mjs";
import "../_libs/zod.mjs";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";




function RiggingLiftPlan({ className = "" }) {
  const arcs = [
    { r: 90, label: "R24400" },
    { r: 110, label: "R26400" },
    { r: 135, label: "R29800" },
    { r: 160, label: "R32500" },
    { r: 185, label: "R34320" }
  ];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "svg",
    {
      className,
      viewBox: "0 0 900 560",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "0.8",
      style: { color: "var(--ink)", width: "100%", height: "100%" },
      preserveAspectRatio: "xMidYMid meet",
      fontFamily: "ui-monospace, SFMono-Regular, monospace",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("rect", { x: "6", y: "6", width: "888", height: "548", stroke: "currentColor", strokeWidth: "1.4" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("rect", { x: "14", y: "14", width: "872", height: "532", strokeWidth: "0.4", opacity: "0.5" }),
        Array.from({ length: 16 }).map((_, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("g", { opacity: "0.7", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: 14 + 872 / 16 * i, y1: "14", x2: 14 + 872 / 16 * i, y2: "22", strokeWidth: "0.4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: 14 + 872 / 16 * i, y1: "538", x2: 14 + 872 / 16 * i, y2: "546", strokeWidth: "0.4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: 14 + 872 / 16 * i + 2, y: "20", fontSize: "6", fill: "currentColor", opacity: "0.6", children: i + 1 })
        ] }, `t${i}`)),
        /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "430", y1: "30", x2: "430", y2: "430", strokeDasharray: "3 3", opacity: "0.5" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("g", { transform: "translate(28,34)", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("rect", { x: "0", y: "0", width: "180", height: "150", strokeWidth: "0.7" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: "6", y: "11", fontSize: "8", fontWeight: "700", fill: "currentColor", children: "Main Crane Data" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: "6", y: "20", fontSize: "5.5", opacity: "0.7", children: "[Demag CC8800-1]" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "0", y1: "24", x2: "180", y2: "24", strokeWidth: "0.5" }),
          [
            ["Crane Configuration", "SWBL"],
            ["Main boom length", "108.0 m"],
            ["Main boom angle", "84.0 °"],
            ["Jib length", "108.0 m"],
            ["Jib angle", "26.75 °"],
            ["SL Mast", "50 m"],
            ["SL Radius", "24.0 m"],
            ["Counterweight", "235 t"],
            ["Working radius (max)", "84.0 m"],
            ["Hook block weight", "7.70 t"],
            ["Static Hook Load", "13.39 t"],
            ["DAF (15%)", "1.99"],
            ["Dynamic Lift Load", "15.38 t"],
            ["Crane chart capacity", "21.80 t"],
            ["% chart capacity", "70.73 %"]
          ].map(([k, v], i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("g", { transform: `translate(0, ${30 + i * 7.5})`, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: "6", y: "0", fontSize: "5.5", fill: "currentColor", children: k }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: "174", y: "0", fontSize: "5.5", fill: "currentColor", textAnchor: "end", children: v }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "6", y1: "2", x2: "174", y2: "2", strokeWidth: "0.2", opacity: "0.3" })
          ] }, k))
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("g", { transform: "translate(220,40)", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "-10", y1: "370", x2: "220", y2: "370", strokeWidth: "0.6" }),
          Array.from({ length: 22 }).map((_, i) => /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: -10 + i * 11, y1: "370", x2: -15 + i * 11, y2: "378", strokeWidth: "0.3", opacity: "0.5" }, i)),
          /* @__PURE__ */ jsxRuntimeExports.jsx("polygon", { points: "40,360 160,360 175,374 25,374", strokeWidth: "0.7" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "40", y1: "360", x2: "160", y2: "360", opacity: "0.4" }),
          Array.from({ length: 14 }).map((_, i) => /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: 40 + i * 9, y1: "360", x2: 32 + i * 9, y2: "374", strokeWidth: "0.3", opacity: "0.5" }, `tr${i}`)),
          /* @__PURE__ */ jsxRuntimeExports.jsx("ellipse", { cx: "100", cy: "356", rx: "48", ry: "6", strokeWidth: "0.7" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("ellipse", { cx: "100", cy: "354", rx: "48", ry: "6", opacity: "0.4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("rect", { x: "58", y: "320", width: "40", height: "32", strokeWidth: "0.7" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "58", y1: "328", x2: "98", y2: "328", opacity: "0.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "58", y1: "336", x2: "98", y2: "336", opacity: "0.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "58", y1: "344", x2: "98", y2: "344", opacity: "0.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("rect", { x: "2", y: "344", width: "48", height: "10", strokeWidth: "0.6" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("rect", { x: "6", y: "332", width: "40", height: "14", strokeWidth: "0.6" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: "26", y: "342", fontSize: "4.5", textAnchor: "middle", children: "SL-Ballast" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("rect", { x: "100", y: "324", width: "22", height: "28", strokeWidth: "0.6" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("rect", { x: "103", y: "328", width: "16", height: "10", strokeWidth: "0.3", opacity: "0.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: "111", y: "350", fontSize: "4", textAnchor: "middle", opacity: "0.7", children: "CAB" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "105", y1: "324", x2: "135", y2: "220", strokeWidth: "0.7" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "135", y1: "324", x2: "135", y2: "220", strokeWidth: "0.6", opacity: "0.7" }),
          Array.from({ length: 8 }).map((_, i) => {
            const t = i / 8;
            return /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: 105 + (135 - 105) * t, y1: 324 + (220 - 324) * t, x2: 135, y2: 324 + (220 - 324) * (t + 0.05), strokeWidth: "0.3", opacity: "0.5" }, `m${i}`);
          }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "40", y1: "344", x2: "115", y2: "220", strokeWidth: "0.6", opacity: "0.8" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "50", y1: "344", x2: "120", y2: "222", strokeWidth: "0.4", opacity: "0.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: "80", y: "290", fontSize: "4.5", opacity: "0.7", children: "SL-Mast 50m" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "120", y1: "324", x2: "320", y2: "60", strokeWidth: "0.9" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "132", y1: "332", x2: "332", y2: "68", strokeWidth: "0.9" }),
          Array.from({ length: 28 }).map((_, i) => {
            const t = i / 28;
            const x1 = 120 + (320 - 120) * t;
            const y1 = 324 + (60 - 324) * t;
            const x2 = 132 + (332 - 132) * (t + 0.035);
            const y2 = 332 + (68 - 332) * (t + 0.035);
            return /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1, y1, x2, y2, strokeWidth: "0.3", opacity: "0.55" }, `d${i}`);
          }),
          Array.from({ length: 14 }).map((_, i) => {
            const t = i / 14;
            const x1 = 120 + (320 - 120) * t;
            const y1 = 324 + (60 - 324) * t;
            const x2 = 132 + (332 - 132) * t;
            const y2 = 332 + (68 - 332) * t;
            return /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1, y1, x2, y2, strokeWidth: "0.3", opacity: "0.45" }, `v${i}`);
          }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("circle", { cx: "320", cy: "60", r: "3", fill: "currentColor" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "320", y1: "60", x2: "430", y2: "20", strokeWidth: "0.7" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "324", y1: "68", x2: "434", y2: "28", strokeWidth: "0.7" }),
          Array.from({ length: 16 }).map((_, i) => {
            const t = i / 16;
            const x1 = 320 + (430 - 320) * t;
            const y1 = 60 + (20 - 60) * t;
            const x2 = 324 + (434 - 324) * (t + 0.06);
            const y2 = 68 + (28 - 68) * (t + 0.06);
            return /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1, y1, x2, y2, strokeWidth: "0.25", opacity: "0.55" }, `jd${i}`);
          }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "135", y1: "220", x2: "320", y2: "60", strokeDasharray: "2 2", strokeWidth: "0.4", opacity: "0.7" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "135", y1: "220", x2: "430", y2: "20", strokeDasharray: "2 2", strokeWidth: "0.4", opacity: "0.7" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "430", y1: "22", x2: "430", y2: "200", strokeDasharray: "1 2", strokeWidth: "0.5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("rect", { x: "422", y: "200", width: "16", height: "8", strokeWidth: "0.6" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M425 208 L435 208 L435 218 Q430 226 425 218 Z", strokeWidth: "0.6" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: "260", y: "180", fontSize: "5.5", opacity: "0.85", children: "Main Boom 108 m · Angle 84°" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: "350", y: "48", fontSize: "5.5", opacity: "0.85", children: "Jib 108 m · Angle 26.75°" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("circle", { cx: "430", cy: "20", r: "2", fill: "currentColor" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: "0", y: "396", fontSize: "6", fontWeight: "700", children: "ISOMETRIC VIEW · CC8800-1 · SCALE 1:720" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("g", { transform: "translate(660,210)", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("g", { transform: "translate(150,-150)", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("circle", { r: "14", strokeWidth: "0.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M0,-14 L4,0 L0,14 L-4,0 Z", fill: "currentColor", opacity: "0.6" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: "0", y: "-18", fontSize: "6", textAnchor: "middle", children: "N" })
          ] }),
          arcs.map((a, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("g", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "path",
              {
                d: `M ${-a.r} 0 A ${a.r} ${a.r} 0 0 1 ${a.r} 0`,
                strokeDasharray: i % 2 === 0 ? "0" : "3 2",
                strokeWidth: "0.5",
                opacity: 0.8 - i * 0.08
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: a.r + 2, y: -2, fontSize: "5", opacity: "0.8", children: a.label })
          ] }, a.label)),
          /* @__PURE__ */ jsxRuntimeExports.jsx("circle", { r: "3", fill: "currentColor" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "-8", y1: "0", x2: "8", y2: "0", strokeWidth: "0.4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "0", y1: "-8", x2: "0", y2: "8", strokeWidth: "0.4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: "-12", y: "12", fontSize: "5", textAnchor: "end", children: "CRANE C/L" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("rect", { x: "-30", y: "-22", width: "60", height: "44", strokeWidth: "0.7" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("rect", { x: "-30", y: "-22", width: "14", height: "44", strokeWidth: "0.4", opacity: "0.6" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("rect", { x: "16", y: "-22", width: "14", height: "44", strokeWidth: "0.4", opacity: "0.6" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("rect", { x: "-12", y: "-8", width: "24", height: "16", strokeWidth: "0.4", opacity: "0.6" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("g", { transform: "translate(150,-90) rotate(20)", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("rect", { x: "-30", y: "-18", width: "60", height: "36", strokeWidth: "0.8" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "-30", y1: "-18", x2: "30", y2: "18", strokeWidth: "0.3", opacity: "0.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "30", y1: "-18", x2: "-30", y2: "18", strokeWidth: "0.3", opacity: "0.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: "0", y: "3", fontSize: "5", textAnchor: "middle", children: "FLARE TIP · 13.39 t" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("g", { transform: "translate(-130,-60)", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("rect", { x: "-22", y: "-14", width: "44", height: "28", strokeWidth: "0.6", strokeDasharray: "2 2" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: "0", y: "2", fontSize: "5", textAnchor: "middle", children: "PICKUP" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M -160 0 A 160 160 0 0 1 160 0", strokeDasharray: "5 3", strokeWidth: "0.5", opacity: "0.4", stroke: "var(--red)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "0", y1: "60", x2: "150", y2: "60", strokeWidth: "0.4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "0", y1: "56", x2: "0", y2: "64", strokeWidth: "0.4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "150", y1: "56", x2: "150", y2: "64", strokeWidth: "0.4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: "75", y: "70", fontSize: "5", textAnchor: "middle", children: "29789.94 mm" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "-130", y1: "80", x2: "0", y2: "80", strokeWidth: "0.4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "-130", y1: "76", x2: "-130", y2: "84", strokeWidth: "0.4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "0", y1: "76", x2: "0", y2: "84", strokeWidth: "0.4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: "-65", y: "90", fontSize: "5", textAnchor: "middle", children: "22086.67 mm" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: "0", y: "115", fontSize: "6", fontWeight: "700", textAnchor: "middle", children: "PLAN VIEW · FLARE AREA · SCALE 1:720" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("g", { transform: "translate(28,440)", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("rect", { x: "0", y: "0", width: "540", height: "100", strokeWidth: "0.7" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: "6", y: "11", fontSize: "7", fontWeight: "700", children: "GBP Calculation Under Mat (Main Crane)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "0", y1: "15", x2: "540", y2: "15", strokeWidth: "0.4" }),
          ["", "Aaxl (t/m²)", "Bxct (t/m²)", "Cxct (t/m²)", "Daxl (t/m²)"].map((h, i) => /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: 6 + i * 108, y: "24", fontSize: "5.5", fontWeight: "700", opacity: "0.85", children: h }, i)),
          [
            ["Steel Mat", "8.4", "35.7", "17.4", "44.7"],
            ["Load (act.)", "—", "9.6", "—", "—"],
            ["GBPact. Under Mat", "—", "1.6", "—", "—"],
            ["Steel Mat", "Amax", "Bmax", "Cmax", "Dmax"],
            ["Load (max.)", "46.6", "46.6", "46.6", "46.6"],
            ["GBPmax. Under Mat", "—", "10.2", "—", "—"]
          ].map((row, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("g", { transform: `translate(0,${32 + i * 9})`, children: [
            row.map((c, j) => /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: 6 + j * 108, y: "0", fontSize: "5", children: c }, j)),
            /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "6", y1: "2", x2: "534", y2: "2", strokeWidth: "0.2", opacity: "0.3" })
          ] }, i))
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("g", { transform: "translate(580,440)", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("rect", { x: "0", y: "0", width: "290", height: "100", strokeWidth: "0.7" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: "6", y: "11", fontSize: "7", fontWeight: "700", children: "Maximum Allowable Wind Speed" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "0", y1: "15", x2: "290", y2: "15", strokeWidth: "0.4" }),
          [
            ["Weight to be lifted", "Wt", "5000 kg"],
            ["Maximum wind speed", "Vmax", "9.5 m/s"],
            ["Dynamic pressure", "q of P", "60.03 N/m²"],
            ["Resulting wind force", "Fw", "493.2 N"],
            ["Wind resistant coeff.", "Cw", "1.6"],
            ["Projected area", "Aw", "7.552 m²"],
            ["Calculated wind speed", "Vcal", "9.59 m/s"]
          ].map(([k, sym, v], i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("g", { transform: `translate(0,${22 + i * 9.5})`, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: "6", y: "0", fontSize: "5", children: k }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: "170", y: "0", fontSize: "5", opacity: "0.7", children: sym }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: "284", y: "0", fontSize: "5", textAnchor: "end", fontWeight: "700", children: v }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "6", y1: "2", x2: "284", y2: "2", strokeWidth: "0.2", opacity: "0.3" })
          ] }, k))
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("g", { transform: "translate(28,548)", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: "0", y: "-2", fontSize: "5.5", opacity: "0.6", children: "ASCENTEZ · LIFT ENGINEERING · DWG-RIG-001 · REV A · SHEET 09" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("text", { x: "844", y: "-2", fontSize: "5.5", opacity: "0.6", textAnchor: "end", children: "ADNOC OS-ST-19 · BS 7121 · LOLER" })
        ] })
      ]
    }
  );
}
const blocks = [{
  id: "lift-engineering",
  idx: "01",
  title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    "Lift",
    /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
    "Engineering"
  ] }),
  dark: false,
  lead: "Before anything moves, we draw the lift. 2D layout, 3D simulation, load chart at the working radius, rigging and sling calculations. The documentation that gets your HSE team to sign off the first time.",
  feats: [["2D and 3D Lift Plans", "Rendered simulations with crane configuration, working radius, and clearance envelopes. Verified against the manufacturer load chart at the actual radius."], ["Route and Transport Studies", "Oversized load routing, bridge and road load checks, clearance measurements, escort planning."], ["Rigging Design", "Sling selection, shackle sizing, spreader bar specification, lift point verification, tailing sequence."], ["Method Statement and JSA", "Lift sequence, hold points, emergency response, competency matrix. Formatted to client HSE and ADNOC OS-ST-19."]],
  specs: [["Deliverables", "2D Drawings · 3D Model · Method Statement"], ["Standards", "ADNOC OS-ST-19 · BS 7121 · LOLER"], ["Typical Turnaround", "3 to 10 working days"], ["Software", "Liebherr LICCON · Demag IC-1 · 3D Lift Plan"]],
  cta: "Need a lift plan?",
  ctaBtn: "Request a Plan"
}, {
  id: "transportation",
  idx: "02",
  title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    "Heavy",
    /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "Transport" }),
    "ation"
  ] }),
  dark: true,
  lead: "Oversized cargo, long routes, live plant access. We plan the move, verify the route, escort the load, and sign it off at delivery.",
  feats: [["SPMT and Trailer Transport", "Self-Propelled Modular Transporters for heavy modules. Low-bed trailers to 120T. Axle loading optimised route by route."], ["Route Surveys", "Physical and GIS route survey. Bridge ratings, power line clearances, turn radii, night-move permits."], ["Equipment Transport", "Refinery equipment, power plant modules, wind turbine components, mining plant."], ["On-Site Coordination", "Transport supervisor on the load. Dedicated escort. Direct interface with your site and the authorities."]],
  cta: "Moving something oversized?",
  ctaBtn: "Plan the Move"
}, {
  id: "rigging",
  idx: "03",
  title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    "Rigging, Jacking",
    /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
    "and Installation"
  ] }),
  dark: false,
  lead: "The lift is one part. The receiving side is the other. We rig it, jack it, land it, and bolt it down.",
  feats: [["Heavy Machinery Installation", "Precision placement on foundation. Levelling, grouting coordination, alignment verification."], ["Rigging and Jacking Services", "Hydraulic skidding and jacking for loads that cannot be craned. Controlled descent for hot-side replacements."], ["Turnkey Execution", "Single contract from planning to commissioning. One team, one accountability line."], ["Flare Tip Replacement", "Extreme-height lifts with full supervision. Borouge 3 at 190m is the reference."], ["Custom Rigging Equipment Design and Build", "In-house rigging engineers design bespoke spreader beams, lifting frames, baskets, and tailing fixtures when off-the-shelf gear will not do. Fabricated in our own facility, proof-load tested, and certified before it ships."]],
  cta: "Shutdown coming up?",
  ctaBtn: "Plan the Shutdown"
}, {
  id: "manpower",
  idx: "04",
  title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    "Manpower",
    /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
    "and ",
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "APLO" })
  ] }),
  dark: true,
  lead: "Single Point Authority. Qualified, certified, audited. From rigging engineer to signaller.",
  feats: [["Single Point Authority", "One accountable lead per project. Coordinates engineering, HSE, crane crews, and client interface."], ["Rigging Engineer and APLO", "Appointed Person for Lifting Operations. Full responsibility for planning, supervision, and close-out."], ["Safety Officer", "On-site HSE for toolbox talks, JSA, emergency preparedness, and continuous supervision."], ["Supervisors, Riggers, Signallers", "Competency-validated crews. Certified to the client's standard. Audited before mobilisation."]],
  cta: "Need qualified lifting crew?",
  ctaBtn: "Request Manpower"
}, {
  id: "crane-rental",
  idx: "05",
  title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    "Crane",
    /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
    "Rental"
  ] }),
  dark: false,
  lead: "Mobile cranes 45t to 500t. Crawler cranes 80t to 1,600t. With or without operator. Short hire to long campaign.",
  feats: [["Mobile Cranes: 45t to 500t", "All-terrain and rough-terrain cranes for fast mobilisation and restricted sites. Demag, Liebherr, and Grove fleet."], ["Crawler Cranes: 80t to 1,600t", "Heavy lattice-boom crawlers for modules, flare tips, long-reach lifts. Demag CC2800-1 and CC8800-1 in the fleet."], ["Operated or Bare Lease", "Cranes delivered with certified operator and full maintenance regime. Or bare lease to your accredited crew."], ["Transportation Included", "Mobilisation, assembly, and demobilisation handled end to end. You point to the pad. We bring the crane."]],
  cta: "Looking for the right crane?",
  ctaBtn: "Browse the Fleet",
  ctaLink: "/fleet"
}, {
  id: "tools-rental",
  idx: "06",
  title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    "Lifting Tools",
    /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
    "Rental"
  ] }),
  dark: true,
  lead: "Certified spreader beams, lifting frames, baskets, and bespoke rigging gear. Inspected, tagged, ready.",
  feats: [["Spreader and Lifting Beams", "Standard and modular spreader beams from 5t up to 1,000t. Load-tested and certified."], ["Lifting Frames", "Square and cross frames from 1t to 100t. Jumbo bag frames for 2 to 20 bags simultaneously."], ["Man and Material Baskets", "Engineered personnel and material baskets. Certified lifting points. Secondary attachments."], ["Modular Test Weights", "Calibrated test weights from 1t to 100t. Proof-load testing for cranes, hoists, and lifting gear."]],
  cta: "Need certified rigging gear?",
  ctaBtn: "Check Availability"
}, {
  id: "tools-trading",
  idx: "07",
  title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    "Lifting Tools",
    /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "Trading" })
  ] }),
  dark: false,
  lead: "Sales of certified lifting equipment. In-house brand and OEM partners.",
  feats: [["Spreader Beams up to 1,000t", "In-house designed and fabricated. Proof-load certificate with every unit."], ["Shackles up to 1,250t", "Bow and dee shackles. Green Pin and equivalent marine-grade."], ["Chain Pulley Blocks up to 40t", "Manual and lever-operated chain blocks. Kito, Yale, Vital in stock."], ["Wire Rope and Webbing Slings", "Polyester round slings, webbing slings, wire rope slings with reinforced terminations."]],
  cta: "Buying lifting gear?",
  ctaBtn: "Get a Quote"
}];
function ServicesPage() {
  const {
    open
  } = useQuoteModal();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Nav, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "svc-hero", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eyebrow eyebrow-red", children: "Services · 01 to 07" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "svc-hero-h1", style: {
          marginTop: 24
        }, children: [
          "Seven service lines.",
          /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
          "One ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "red", children: "accountable" }),
          " team."
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "svc-hero-p", children: "Ascentez handles the full chain. Engineering, transportation, supervision, equipment, tools, and manpower. You pick the scope. We are accountable end to end." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "actions", style: {
          marginTop: 32,
          display: "flex",
          gap: 12,
          flexWrap: "wrap"
        }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: () => open("Services hero"), className: "btn btn-red", children: [
            "Contact Sales ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "arrow", children: "→" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("a", { className: "btn btn-ghost", href: "#lift-engineering", children: "Browse Services ↓" })
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("nav", { className: "svc-anchors", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "wrap", children: blocks.map((b) => /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { href: `#${b.id}`, children: [
      b.idx,
      " · ",
      b.id.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase())
    ] }, b.id)) }) }),
    blocks.map((b) => /* @__PURE__ */ jsxRuntimeExports.jsx("section", { id: b.id, className: `svc-block${b.dark ? " dark" : ""}`, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "svc-block-head", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "svc-block-idx", children: [
            b.idx,
            " · Service"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "svc-block-h2", children: b.title })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "svc-block-lead", children: b.lead }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "svc-features", children: b.feats.map(([h, p]) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "svc-feat", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { children: h }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: p })
      ] }, h)) }),
      b.specs && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "spec-strip", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "spec-strip-visual", children: /* @__PURE__ */ jsxRuntimeExports.jsx(RiggingLiftPlan, {}) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "spec-rows", children: b.specs.map(([k, v]) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "row", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: k }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "v", children: v })
        ] }, k)) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "svc-cta-row", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: {
          fontFamily: "var(--f-mono)",
          fontSize: 12,
          letterSpacing: "0.14em",
          textTransform: "uppercase",
          color: b.dark ? "var(--steel-2)" : "var(--steel)"
        }, children: b.cta }),
        b.ctaLink ? /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: b.ctaLink, className: "quote-trigger", children: [
          b.ctaBtn,
          " ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "→" })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: () => open(`Service · ${b.id}`), className: "quote-trigger", children: [
          b.ctaBtn,
          " ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "→" })
        ] })
      ] })
    ] }) }, b.id)),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "final-cta-s", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "wrap", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "eyebrow", style: {
        color: "#0A0A0A"
      }, children: "Ready when you are" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "final-cta-h2", children: [
        "One form.",
        /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
        "One engineer.",
        /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
        "One plan."
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Tell us the lift. We will send back the right crane, the right team, and the right plan." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: () => open("Services · Final CTA"), className: "btn", children: [
        "Contact Sales ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "arrow", children: "→" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Footer, {})
  ] });
}
export {
  ServicesPage as component
};
