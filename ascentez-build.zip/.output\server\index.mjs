globalThis.__nitro_main__ = import.meta.url;
import "./_libs/unenv.mjs";

import { H as HookableCore } from "./_libs/hookable.mjs";
import { d as defineLazyEventHandler, H as HTTPError, a as H3Core } from "./_libs/h3.mjs";
import { d as FastResponse } from "./_libs/srvx.mjs";


import "./_libs/rou3.mjs";





function lazyService(loader) {
  let promise, mod;
  return {
    fetch(req) {
      if (mod) {
        return mod.fetch(req);
      }
      if (!promise) {
        promise = loader().then((_mod) => mod = _mod.default || _mod);
      }
      return promise.then((mod2) => mod2.fetch(req));
    }
  };
}
const services = {
  ["ssr"]: lazyService(() => import("./_ssr/index.mjs"))
};
globalThis.__nitro_vite_envs__ = services;
const assets = {
  "/assets/about-CnsvdFkE.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"22c0-UzR7vIf3GXpGk4GFTOOg7D/M5Qw"',
    "mtime": "2026-09-10T11:08:05.886Z",
    "size": 8896,
    "path": "../public/assets/about-CnsvdFkE.js"
  },
  "/assets/case-studies-DDdoEY_t.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"200e-wfFXh0aq+QGNO0rUj2ye7XMHQ6I"',
    "mtime": "2026-09-10T11:08:05.886Z",
    "size": 8206,
    "path": "../public/assets/case-studies-DDdoEY_t.js"
  },
  "/assets/contact-BEgXX15G.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2277-IDHSbtZsMHqAGE1FDAkAolyjug8"',
    "mtime": "2026-09-10T11:08:05.886Z",
    "size": 8823,
    "path": "../public/assets/contact-BEgXX15G.js"
  },
  "/assets/Footer-NrDtBO-G.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"10e8-CrFqBdo/cSQG6T6vXWmi0pB/EO8"',
    "mtime": "2026-09-10T11:08:05.887Z",
    "size": 4328,
    "path": "../public/assets/Footer-NrDtBO-G.js"
  },
  "/assets/Cranes-DG6ph5DA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"243b-swR8MVHVGCdzWP/0Jz7iIzJIah0"',
    "mtime": "2026-09-10T11:08:05.887Z",
    "size": 9275,
    "path": "../public/assets/Cranes-DG6ph5DA.js"
  },
  "/assets/fleet-DAVv6TIp.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2540-HyuDrzyHLzBBJG8njX9Nyj1bCuQ"',
    "mtime": "2026-09-10T11:08:05.886Z",
    "size": 9536,
    "path": "../public/assets/fleet-DAVv6TIp.js"
  },
  "/assets/index-wO4hsesP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"3220-99WYYmw6nkwPfYlcDikUf9phuJs"',
    "mtime": "2026-09-10T11:08:05.887Z",
    "size": 12832,
    "path": "../public/assets/index-wO4hsesP.js"
  },
  "/assets/services-BOEdyblm.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"4fbc-n29dec9nfbHV9Wv1XKWIIMrna3k"',
    "mtime": "2026-09-10T11:08:05.886Z",
    "size": 20412,
    "path": "../public/assets/services-BOEdyblm.js"
  },
  "/assets/index-DJWOS-qZ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"532fa-pIHGDO1nQvQiPP67aB81/bWEVwU"',
    "mtime": "2026-09-10T11:08:05.886Z",
    "size": 340730,
    "path": "../public/assets/index-DJWOS-qZ.js"
  },
  "/favicon.png": {
    "type": "image/png",
    "etag": '"43f7-POcO7VTeMPb67Ram0tYB38a0uYI"',
    "mtime": "2026-09-10T09:57:02.857Z",
    "size": 17399,
    "path": "../public/favicon.png"
  },
  "/assets/logo-dark-B8JWIN3g.png": {
    "type": "image/png",
    "etag": '"cf15-/KtBOzT6KiHoYEZNpMaVSqn5xq4"',
    "mtime": "2026-09-10T11:08:05.886Z",
    "size": 53013,
    "path": "../public/assets/logo-dark-B8JWIN3g.png"
  },
  "/assets/logo-light-Djg0x8wR.png": {
    "type": "image/png",
    "etag": '"f0f1-1uhMD5mC3HyQfVRV0kEWQhifCXo"',
    "mtime": "2026-09-10T11:08:05.886Z",
    "size": 61681,
    "path": "../public/assets/logo-light-Djg0x8wR.png"
  },
  "/assets/styles-CC8XCjyM.css": {
    "type": "text/css; charset=utf-8",
    "etag": '"109b6-ODZUr3oaNIsxEjwJuqAVTlryqFo"',
    "mtime": "2026-09-10T11:08:05.886Z",
    "size": 68022,
    "path": "../public/assets/styles-CC8XCjyM.css"
  }
};
const publicAssetBases = {};
function isPublicAssetURL(id = "") {
  if (assets[id]) {
    return true;
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) {
      return true;
    }
  }
  return false;
}
const headers = ((m) => function headersRouteRule(event) {
  for (const [key, value] of Object.entries(m.options || {})) {
    event.res.headers.set(key, value);
  }
});
const findRouteRules = /* @__PURE__ */ (() => {
  const $0 = [{ name: "headers", route: "/assets/**", handler: headers, options: { "cache-control": "public, max-age=31536000, immutable" } }];
  return (m, p) => {
    let r = [];
    if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
    let s = p.split("/"), l = s.length;
    if (l > 1) {
      if (s[1] === "assets") {
        r.unshift({ data: $0, params: { "_": s.slice(2).join("/") } });
      }
    }
    return r;
  };
})();
const _lazy_wjc2dv = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
const findRoute = /* @__PURE__ */ (() => {
  const data = { route: "/**", handler: _lazy_wjc2dv };
  return ((_m, p) => {
    return { data, params: { "_": p.slice(1) } };
  });
})();
const errorHandler$1 = (error, event) => {
  const res = defaultHandler(error, event);
  return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
  const unhandled = error.unhandled ?? !HTTPError.isError(error);
  const { status = 500, statusText = "" } = unhandled ? {} : error;
  if (status === 404) {
    const url = event.url || new URL(event.req.url);
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      return {
        status: 302,
        headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
      };
    }
  }
  const headers2 = new Headers(unhandled ? {} : error.headers);
  headers2.set("content-type", "application/json; charset=utf-8");
  const jsonBody = unhandled ? {
    status,
    unhandled: true
  } : typeof error.toJSON === "function" ? error.toJSON() : {
    status,
    statusText,
    message: error.message
  };
  return {
    status,
    statusText,
    headers: headers2,
    body: {
      error: true,
      ...jsonBody
    }
  };
}
const errorHandlers = [errorHandler$1];
async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      const response = await handler(error, event, { defaultHandler });
      if (response) {
        return response;
      }
    } catch (error2) {
      console.error(error2);
    }
  }
}
function createNitroApp() {
  const captureError = (error, errorCtx) => {
    if (errorCtx?.event) {
      const errors = errorCtx.event.req.context?.nitro?.errors;
      if (errors) {
        errors.push({ error, context: errorCtx });
      }
    }
  };
  const h3App = createH3App({
    onError(error, event) {
      return errorHandler(error, event);
    }
  });
  let appHandler = (req) => {
    req.context ||= {};
    req.context.nitro = req.context.nitro || { errors: [] };
    return h3App.fetch(req);
  };
  return {
    fetch: appHandler,
    h3: h3App,
    hooks: void 0,
    captureError
  };
}
function createH3App(config) {
  const h3App = new H3Core(config);
  h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
  h3App["~getMiddleware"] = (event, route) => {
    const pathname = event.url.pathname;
    const method = event.req.method;
    const middleware = [];
    const routeRules = getRouteRules(method, pathname);
    event.context.routeRules = routeRules?.routeRules;
    if (routeRules?.routeRuleMiddleware.length) {
      middleware.push(...routeRules.routeRuleMiddleware);
    }
    if (route?.data?.middleware?.length) {
      middleware.push(...route.data.middleware);
    }
    return middleware;
  };
  return h3App;
}
const APP_ID = "default";
function useNitroApp() {
  let instance = useNitroApp._instance;
  if (instance) {
    return instance;
  }
  instance = useNitroApp._instance = createNitroApp();
  globalThis.__nitro__ = globalThis.__nitro__ || {};
  globalThis.__nitro__[APP_ID] = instance;
  return instance;
}
function useNitroHooks() {
  const nitroApp = useNitroApp();
  const hooks = nitroApp.hooks;
  if (hooks) {
    return hooks;
  }
  return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
  const m = findRouteRules(method, pathname);
  if (!m?.length) {
    return { routeRuleMiddleware: [] };
  }
  const routeRules = {};
  for (const layer of m) {
    for (const rule of layer.data) {
      const currentRule = routeRules[rule.name];
      if (currentRule) {
        if (rule.options === false) {
          delete routeRules[rule.name];
          continue;
        }
        if (typeof currentRule.options === "object" && typeof rule.options === "object") {
          currentRule.options = {
            ...currentRule.options,
            ...rule.options
          };
        } else {
          currentRule.options = rule.options;
        }
        currentRule.route = rule.route;
        currentRule.params = {
          ...currentRule.params,
          ...layer.params
        };
      } else if (rule.options !== false) {
        routeRules[rule.name] = {
          ...rule,
          params: layer.params
        };
      }
    }
  }
  const middleware = [];
  const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
  for (const rule of orderedRules) {
    if (rule.options === false || !rule.handler) {
      continue;
    }
    middleware.push(rule.handler(rule));
  }
  return {
    routeRules,
    routeRuleMiddleware: middleware
  };
}
function createHandler(hooks) {
  const nitroApp = useNitroApp();
  const nitroHooks = useNitroHooks();
  return {
    async fetch(request, env, context) {
      globalThis.__env__ = env;
      augmentReq(request, {
        env,
        context
      });
      const ctxExt = {};
      const url = new URL(request.url);
      if (hooks.fetch) {
        const res = await hooks.fetch(request, env, context, url, ctxExt);
        if (res) {
          return res;
        }
      }
      return await nitroApp.fetch(request);
    },
    scheduled(controller, env, context) {
      globalThis.__env__ = env;
      context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
        controller,
        env,
        context
      }) || Promise.resolve());
    },
    email(message, env, context) {
      globalThis.__env__ = env;
      context.waitUntil(nitroHooks.callHook("cloudflare:email", {
        message,
        event: message,
        env,
        context
      }) || Promise.resolve());
    },
    queue(batch, env, context) {
      globalThis.__env__ = env;
      context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
        batch,
        event: batch,
        env,
        context
      }) || Promise.resolve());
    },
    tail(traces, env, context) {
      globalThis.__env__ = env;
      context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
        traces,
        env,
        context
      }) || Promise.resolve());
    },
    trace(traces, env, context) {
      globalThis.__env__ = env;
      context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
        traces,
        env,
        context
      }) || Promise.resolve());
    }
  };
}
function augmentReq(cfReq, ctx) {
  const req = cfReq;
  req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
  req.runtime ??= { name: "cloudflare" };
  req.runtime.cloudflare = {
    ...req.runtime.cloudflare,
    ...ctx
  };
  req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
const cloudflareModule = createHandler({ fetch(cfRequest, env, context, url) {
  if (env.ASSETS && isPublicAssetURL(url.pathname)) {
    return env.ASSETS.fetch(cfRequest);
  }
} });
export {
  cloudflareModule as default
};
